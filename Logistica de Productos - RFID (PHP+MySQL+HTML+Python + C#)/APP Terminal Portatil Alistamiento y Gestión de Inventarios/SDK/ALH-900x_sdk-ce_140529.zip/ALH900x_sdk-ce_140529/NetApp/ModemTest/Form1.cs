﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using NModemApi;
using NSysSvcApi;
using System.Runtime.InteropServices;
using System.IO;
using Microsoft.Win32;
using System.Threading;

namespace ModemTest
{
    public partial class Form1 : Form
    {
        const string CONFIG_DATA_FILE = @"\Flash Disk\Phone_UI\gprs.ini";
        const string RAS_ENTRY_NAME = "gprs";
        public static ModemApi Modem = new ModemApi();
        public static SysSvcApi SysSvc = new SysSvcApi();

        bool m_bModemPowered = false;
        bool m_bRasConnected = false;
        bool m_bWaitRasEvent = false;
        bool m_bWaitPowerEvent = false;
        bool m_bGoToSleep = false;

        string m_APN = String.Empty;
        string m_UserName = String.Empty;
        string m_Password = String.Empty;
        string m_PhoneNum = String.Empty;
        string m_LocalCall = String.Empty;
        string m_LongDistanceCall = String.Empty;   
        string m_InternationalCall = String.Empty;

        const int REGISTERED_DELAY = 10000;
        const int NOT_REGISTERED_DELAY = 3000;

        NotifyIcon m_notifyIcon;
        RAS_TEST.RAS ras;
        Thread threadNetworkStatus = null;
        MODEM_NETWORK_REGISTRATION_STATUS g_NetworkStatus = MODEM_NETWORK_REGISTRATION_STATUS.UNKNOWN;
        bool m_bSimChecked = false;

        public delegate void SetStatusString(string status);
        void SetStatusStringProc(string status)
        {
            AddModemStatus(status);
        }

        void NetworkStatusThreadProc()
        {
            MODEM_NETWORK_REGISTRATION_STATUS status = MODEM_NETWORK_REGISTRATION_STATUS.UNKNOWN;
            while (true)
            {
                if (Modem.IsOpened())
                {
                    status = Modem.GetNetworkRegistrationStatus();
                    if (g_NetworkStatus != status)
                    {
                        //Interlocked.Exchange(ref g_NetworkStatus, status);
                        g_NetworkStatus = status;
                        switch (status)
                        {
                            case MODEM_NETWORK_REGISTRATION_STATUS.REGISTERED_TO_GSM:
                                Invoke(new SetStatusString(SetStatusStringProc), "Registered, 2G Network");
                                m_notifyIcon.Modify(Properties.Resources._2g_ico_off.Handle);
                                break;
                            case MODEM_NETWORK_REGISTRATION_STATUS.REGISTERED_TO_UTRAN:
                                Invoke(new SetStatusString(SetStatusStringProc), "Registered, 3G Network");
                                m_notifyIcon.Modify(Properties.Resources._3g_ico_off.Handle);
                                break;
                            case MODEM_NETWORK_REGISTRATION_STATUS.NOT_REGISTERED_BUT_SEARCHING_OPERATOR:
                            case MODEM_NETWORK_REGISTRATION_STATUS.NOT_REGISTERED:
                            case MODEM_NETWORK_REGISTRATION_STATUS.REGISTRATION_DENIED:
                            case MODEM_NETWORK_REGISTRATION_STATUS.UNKNOWN:
                            case MODEM_NETWORK_REGISTRATION_STATUS.COMMAND_FAILED:
                                m_notifyIcon.Modify(Properties.Resources.disconnect.Handle);
                                break;
                        }
                    }
                }

                if(status == MODEM_NETWORK_REGISTRATION_STATUS.REGISTERED_TO_GSM || status == MODEM_NETWORK_REGISTRATION_STATUS.REGISTERED_TO_UTRAN)
                    Thread.Sleep(REGISTERED_DELAY);
                else
                    Thread.Sleep(NOT_REGISTERED_DELAY);
            }
        }

        public Form1()
        {
            InitializeComponent();
            this.Text = "ModemControl_NET";

            btnConnect.Enabled = false;
            btnDisconnect.Enabled = false;

            if (SysSvc.SleepWakeupNotificationSet(new SysSvcApi.SleepWakeupNotifyCALLBACK(SleepWakeupProc)) != SYSSVC_RESULT.SYSSVC_RESULT_SUCCESS)
            {
                MessageBox.Show("SleepWakeupNotificationSet failed");
                Application.Exit();
            }

            if (Modem.AllocContext() != MODEM_RESULT.MODEM_RESULT_SUCCESS)
            {
                MessageBox.Show("AllocContext failed");
                SysSvc.SleepWakeupNotificationReset();
                Application.Exit();
            }

            if (Modem.SetCallback(new ModemCallbackProc(CallbackProc)) != MODEM_RESULT.MODEM_RESULT_SUCCESS)
            {
                MessageBox.Show("SetCallback failed");
                SysSvc.SleepWakeupNotificationReset();
                Modem.DeallocContext();
                Application.Exit();
            }


            if (Modem.GetPowerStatus() == MODEM_POWER_STATUS.MODEM_POWER_STATUS_ON)
            {
                //Cursor.Current = Cursors.WaitCursor;
                m_bModemPowered = true;
                m_bWaitPowerEvent = true;
                btnConnect.Enabled = true;
                btnDisconnect.Enabled = true;
                AddModemStatus("Registering with Network...");
                if (!Modem.IsOpened())
                    Modem.Open();

                threadNetworkStatus = new Thread(new ThreadStart(NetworkStatusThreadProc));
                threadNetworkStatus.IsBackground = true;
                threadNetworkStatus.Start();
            }

            ras = new RAS_TEST.RAS();
            ras.GetRasDialEvent += new RAS_TEST.RAS.RasDialEventHandler(ras_GetRasDialEvent);

            m_notifyIcon = new NotifyIcon();
            m_notifyIcon.OnDblClick += new NotifyIcon.DblClick(m_notifyIcon_OnDblClick);
            m_notifyIcon.Add(Properties.Resources.disconnect.Handle);

        }

        void m_notifyIcon_OnDblClick()
        {
            IntPtr hWnd = UnManagedAPI.FindWindow(UnManagedAPI.NETCF_WND_CLASS_NAME, "ModemControl_NET");
            if (hWnd != IntPtr.Zero)
            {
                this.Show();
                UnManagedAPI.SetForegroundWindow(hWnd);
            }
        }

        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            if (threadNetworkStatus != null)
            {
                threadNetworkStatus.Abort();
                threadNetworkStatus.Join();
                threadNetworkStatus = null;
            }

            if (Modem.IsOpened())
                Modem.Close();

            if (IsRasConnected())
                Modem.RasHangUp();

            Modem.DeallocContext();

            SysSvc.SleepWakeupNotificationReset();

            m_notifyIcon.Remove();
        }

        void SleepWakeupProc(bool bEnterSleep)
        {
            if (bEnterSleep)
            {
                btnPowerUp.Enabled = false;
                btnPowerDown.Enabled = false;
                btnConnect.Enabled = false;
                btnDisconnect.Enabled = false;

                if (Modem.IsOpened())
                {
                    Modem.Close();
                    g_NetworkStatus = MODEM_NETWORK_REGISTRATION_STATUS.UNKNOWN;
                }

                m_bGoToSleep = true;
                if (IsRasConnected())
                {
                    m_bRasConnected = true;
                    Modem.RasHangUp();
                }
                else
                {
                    m_bRasConnected = false;
                    if (m_bWaitRasEvent)
                    {
                        RAS_TEST.RAS.RasConnState state = RAS_TEST.RAS.RasConnState.RASCS_Unknown;
                        for (int n = 0; n < 60; n++)
                        {
                            state = ras.GetConnectionStatus();
                            if (state == RAS_TEST.RAS.RasConnState.RASCS_Connected)
                                break;

                            System.Threading.Thread.Sleep(1000);
                        }
                        Modem.RasHangUp();
                    }
                }

                if (!UnManagedAPI.DetectBattery)
                {
                    threadNetworkStatus.Abort();
                    threadNetworkStatus.Join();
                    threadNetworkStatus = null;
                    m_bSimChecked = false;
                }

                g_NetworkStatus = MODEM_NETWORK_REGISTRATION_STATUS.UNKNOWN;
            }
            else
            {
                if (!UnManagedAPI.DetectBattery)
                {
                    threadNetworkStatus.Abort();
                    threadNetworkStatus.Join();
                    threadNetworkStatus = null;
                    m_bSimChecked = false;
                    return;
                }

                btnConnect.Enabled = true;
                btnDisconnect.Enabled = true;
                m_bGoToSleep = false;

                btnPowerUp.Enabled = true;
                btnPowerDown.Enabled = true;

                if (m_bModemPowered)
                {
                    AddModemStatus("Registering with Network...");
                    
                    //Cursor.Current = Cursors.WaitCursor;
                    if (!Modem.IsOpened())
                        Modem.Open();

                    if (m_bRasConnected)
                    {
                        m_bRasConnected = false;
                        btnConnect.Enabled = false;
                        this.btnConnect_Click(null, null);
                    }
                }
            }
        }

        void CallbackProc(MODEM_CALLBACK_DATA CallbackData)
        {
            switch ((MODEM_SYS_NOTI)CallbackData.m_UserWnMsg)
            {
                case MODEM_SYS_NOTI.PWR_UP_INITIALIZE:
                    AddModemStatus("PowerUp Initialize...");
                    Cursor.Current = Cursors.WaitCursor;
                    break;
                case MODEM_SYS_NOTI.PWR_UP_SUCCESS:
                    AddModemStatus("PowerUp Succeeded");
                    btnConnect.Enabled = true;
                    btnDisconnect.Enabled = true;
                    m_bModemPowered = true;
                    m_bWaitPowerEvent = false;
                    
                    if (!Modem.IsOpened())
                    {
                        Modem.Open();
                    }

                    tbxPINStatus.Text = "Check SIM ...";

                    if (!Modem.IsOpened())
                        Modem.Open();

                    if (Modem.SimQueryCardHolderStatus() != MODEM_SIM_PIN_AUTH_STATUS.SIM_INSERTED)
                    {
                        MessageBox.Show("SIM not inserted");
                        return;
                    }

                    string Code = String.Empty;
                    string NewCode = String.Empty;
                    FormPINAuth frmAuthWnd;

                    switch (Modem.SimQueryAuthStatus())
                    {
                        case MODEM_SIM_PIN_AUTH_STATUS.SIM_READY:
                            m_bSimChecked = true;
                            tbxPINStatus.Text = "READY";
                            break;

                        case MODEM_SIM_PIN_AUTH_STATUS.SIM_PIN:
                            tbxPINStatus.Text = "PIN";
                            frmAuthWnd = new FormPINAuth("SIM_PIN");
                            if (frmAuthWnd.ShowDialog() == DialogResult.OK)
                            {
                                Code = frmAuthWnd.GetCode;

                                switch (Modem.SimEnterPin(Code))
                                {
                                    case MODEM_SIM_PIN_AUTH_STATUS.INCORRECT_PASSWORD:
                                        MessageBox.Show("Incorrect password!");
                                        return;
                                    case MODEM_SIM_PIN_AUTH_STATUS.INVALID_INPUT_VALUE:
                                        MessageBox.Show("Invalid input value");
                                        return;
                                }

                                if (Modem.SimQueryAuthStatus() != MODEM_SIM_PIN_AUTH_STATUS.SIM_READY)
                                {
                                    MessageBox.Show("EnterPIN failed");
                                    return;
                                }
                            }

                            break;

                        case MODEM_SIM_PIN_AUTH_STATUS.SIM_PUK:
                            tbxPINStatus.Text = "PUK";
                            frmAuthWnd = new FormPINAuth("SIM_PUK");
                            if (frmAuthWnd.ShowDialog() == DialogResult.OK)
                            {
                                Code = frmAuthWnd.GetCode;
                                NewCode = frmAuthWnd.GetNewCode;

                                switch (Modem.SimEnterPuk(Code, NewCode))
                                {
                                    case MODEM_SIM_PIN_AUTH_STATUS.INCORRECT_PASSWORD:
                                        MessageBox.Show("Incorrect password!");
                                        return;
                                    case MODEM_SIM_PIN_AUTH_STATUS.INVALID_INPUT_VALUE:
                                        MessageBox.Show("Invalid input value");
                                        return;
                                }

                                if (Modem.SimQueryAuthStatus() != MODEM_SIM_PIN_AUTH_STATUS.SIM_READY)
                                {
                                    MessageBox.Show("EnterPUK failed");
                                    return;
                                }
                            }
                            break;

                        case MODEM_SIM_PIN_AUTH_STATUS.CARD_HOLDER_TRAY_REMOVED:
                            tbxPINStatus.Text = "SIM not inserted";
                            return;
                    }

                    if (threadNetworkStatus == null)
                    {
                        threadNetworkStatus = new Thread(new ThreadStart(NetworkStatusThreadProc));
                        threadNetworkStatus.IsBackground = true;
                        threadNetworkStatus.Start();
                    }
                    Cursor.Current = Cursors.Default;
                    AddModemStatus("Registering with Network...");
                    break;
                    /*
                case MODEM_SYS_NOTI.NETWORK_REGISTERED:
                    AddModemStatus("PowerUp Succeeded");
                    if (Modem.IsOpened())
                        Modem.Close();

                    btnConnect.Enabled = true;
                    btnDisconnect.Enabled = true;
                    m_bWaitPowerEvent = false;
                    Cursor.Current = Cursors.Default;

                    if (m_bRasConnected)
                    {
                        m_bRasConnected = false;
                        btnConnect_Click(null, null);
                    }
                    break;
                case MODEM_SYS_NOTI.NETWORK_NOT_REGISTERED:
                    AddModemStatus("PowerUp Failed");
                    if (Modem.IsOpened())
                        Modem.Close();

                    m_bWaitPowerEvent = false;
                    Cursor.Current = Cursors.Default;
                    break;
                    */
                case MODEM_SYS_NOTI.PWR_UP_FAIL:
                    AddModemStatus("PowerUp Failed");
                    m_bModemPowered = false;
                    m_bWaitPowerEvent = false;
                    m_notifyIcon.Modify(Properties.Resources.disconnect.Handle);
                    break;
                case MODEM_SYS_NOTI.PWR_DOWN_SUCCESS:
                    Cursor.Current = Cursors.Default;
                    AddModemStatus("PowerDown Succeeded");
                    m_bModemPowered = false;
                    if (Modem.IsOpened())
                        Modem.Close();

                    g_NetworkStatus = MODEM_NETWORK_REGISTRATION_STATUS.UNKNOWN;
                    m_notifyIcon.Modify(Properties.Resources.disconnect.Handle);

                    m_bWaitPowerEvent = false;
                    btnConnect.Enabled = false;
                    btnDisconnect.Enabled = false;
                    break;
                case MODEM_SYS_NOTI.PWR_DOWN_FAIL:
                    AddModemStatus("PowerDown Failed");
                    m_bModemPowered = false;
                    m_bWaitPowerEvent = false;
                    break;
                case MODEM_SYS_NOTI.PORT_OPEN_SUCCESS:
                    break;
                case MODEM_SYS_NOTI.PORT_OPEN_FAIL:
                    break;
                default:
                    break;
            }
        }

        void ras_GetRasDialEvent(RAS_TEST.RAS.RasConnState RasEventMsg)
        {
            AddRasStatus(RasEventMsg.ToString());
            if (RasEventMsg == RAS_TEST.RAS.RasConnState.RASCS_Connected)
            {
                if (g_NetworkStatus == MODEM_NETWORK_REGISTRATION_STATUS.REGISTERED_TO_GSM)
                    m_notifyIcon.Modify(Properties.Resources._2g_ico_on.Handle);
                else if(g_NetworkStatus == MODEM_NETWORK_REGISTRATION_STATUS.REGISTERED_TO_UTRAN)
                    m_notifyIcon.Modify(Properties.Resources._3g_ico_on.Handle);

                UnManagedAPI.Play_Sound(@"\Windows\infbeg.wav");
                m_bRasConnected = true;
                m_bWaitRasEvent = false;
                btnConnect.Enabled = true;
                btnDisconnect.Enabled = true;
            }
            else if (RasEventMsg == RAS_TEST.RAS.RasConnState.RASCS_Disconnected)
            {
                if (g_NetworkStatus == MODEM_NETWORK_REGISTRATION_STATUS.REGISTERED_TO_GSM)
                    m_notifyIcon.Modify(Properties.Resources._2g_ico_off.Handle);
                else if (g_NetworkStatus == MODEM_NETWORK_REGISTRATION_STATUS.REGISTERED_TO_UTRAN)
                    m_notifyIcon.Modify(Properties.Resources._3g_ico_off.Handle);
                else
                    m_notifyIcon.Modify(Properties.Resources.disconnect.Handle);

                UnManagedAPI.Play_Sound(@"\Windows\infend.wav");
                m_bWaitRasEvent = false;
                if (!m_bGoToSleep)
                {
                    m_bRasConnected = false;
                    btnConnect.Enabled = true;
                    btnDisconnect.Enabled = true;
                    Cursor.Current = Cursors.Default;
                }
            }
        }

        void AddModemStatus(string str)
        {
            lbxModemStatus.Items.Add(str);
            lbxModemStatus.SelectedIndex = lbxModemStatus.Items.Count - 1;
        }

        void AddRasStatus(string str)
        {
            lbxRasStatus.Items.Add(str);
            lbxRasStatus.SelectedIndex = lbxRasStatus.Items.Count - 1;
        }

        private void btnPowerUp_Click(object sender, EventArgs e)
        {
            MODEM_RESULT result = MODEM_RESULT.MODEM_RESULT_FAILURE;

            if (!m_bModemPowered)
            {
                result = Modem.PowerUp();
                if (result != MODEM_RESULT.MODEM_RESULT_SUCCESS)
                {
                    if (result == MODEM_RESULT.MODEM_RESULT_LOW_BATTERY)
                        MessageBox.Show("Low Battery");
                    else if (result == MODEM_RESULT.MODEM_RESULT_ALREADY_POWER_ON)
                        MessageBox.Show("Modem is already turned on", "ModemControl_NET", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                    else
                        MessageBox.Show(result.ToString());
                }
                else
                {
                    m_bWaitPowerEvent = true;
                }
            }
            else
            {
                MessageBox.Show("Modem is already turned on", "ModemControl_NET", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
        }

        private void btnPowerDown_Click(object sender, EventArgs e)
        {
            MODEM_RESULT result = MODEM_RESULT.MODEM_RESULT_FAILURE;

            if (IsRasConnected())
            {
                MessageBox.Show("Disconnect RAS connection", "ModemControl_NET", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                return;
            }

            Cursor.Current = Cursors.WaitCursor;

            if (threadNetworkStatus != null)
            {
                threadNetworkStatus.Abort();
                threadNetworkStatus.Join();
                threadNetworkStatus = null;
            }

            result = Modem.PowerDown();
            if (result != MODEM_RESULT.MODEM_RESULT_SUCCESS)
            {
                Cursor.Current = Cursors.Default;
                if (result == MODEM_RESULT.MODEM_RESULT_NOT_POWER_ON)
                    MessageBox.Show("Modem is already turned off", "ModemControl_NET", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                else
                    MessageBox.Show(result.ToString());
            }
            else
            {
                m_bWaitPowerEvent = true;
            }
            
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (Modem.GetPowerStatus() != MODEM_POWER_STATUS.MODEM_POWER_STATUS_ON)
            {
                MessageBox.Show("Modem power is down", "ModemControl_NET", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                return;
            }

            if (IsRasConnected())
            {
                MessageBox.Show("Already connected", "ModemControl_NET", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                return;
            }

            if (ras.ValidateEntryName(null, RAS_ENTRY_NAME) == 0)
            {
                if (!LoadGPRSConfigDataFile())
                {
                    MessageBox.Show("LoadGPRSConfigDataFile failed");
                    return;
                }
            }

            btnConnect.Enabled = false;
            btnDisconnect.Enabled = false;

            if (!m_bSimChecked)
            {
                string Code = String.Empty;
                string NewCode = String.Empty;
                FormPINAuth frmAuthWnd;

                tbxPINStatus.Text = "Check SIM ...";

                if (!Modem.IsOpened())
                    Modem.Open();

                if (Modem.SimQueryCardHolderStatus() != MODEM_SIM_PIN_AUTH_STATUS.SIM_INSERTED)
                {
                    MessageBox.Show("SIM not inserted");
                    Modem.Close();
                    btnConnect.Enabled = true;
                    btnDisconnect.Enabled = true;
                    return;
                }

                switch (Modem.SimQueryAuthStatus())
                {
                    case MODEM_SIM_PIN_AUTH_STATUS.SIM_READY:
                        tbxPINStatus.Text = "READY";
                        break;

                    case MODEM_SIM_PIN_AUTH_STATUS.SIM_PIN:
                        tbxPINStatus.Text = "PIN";
                        frmAuthWnd = new FormPINAuth("SIM_PIN");
                        if (frmAuthWnd.ShowDialog() == DialogResult.OK)
                        {
                            Code = frmAuthWnd.GetCode;

                            switch (Modem.SimEnterPin(Code))
                            {
                                case MODEM_SIM_PIN_AUTH_STATUS.INCORRECT_PASSWORD:
                                    MessageBox.Show("Incorrect password!");
                                    Modem.Close();
                                    btnConnect.Enabled = true;
                                    btnDisconnect.Enabled = true;
                                    return;
                                case MODEM_SIM_PIN_AUTH_STATUS.INVALID_INPUT_VALUE:
                                    MessageBox.Show("Invalid input value");
                                    Modem.Close();
                                    btnConnect.Enabled = true;
                                    btnDisconnect.Enabled = true;
                                    return;
                            }

                            if (Modem.SimQueryAuthStatus() != MODEM_SIM_PIN_AUTH_STATUS.SIM_READY)
                            {
                                MessageBox.Show("EnterPIN failed");
                                Modem.Close();
                                btnConnect.Enabled = true;
                                btnDisconnect.Enabled = true;
                                return;
                            }
                        }

                        break;

                    case MODEM_SIM_PIN_AUTH_STATUS.SIM_PUK:
                        tbxPINStatus.Text = "PUK";
                        frmAuthWnd = new FormPINAuth("SIM_PUK");
                        if (frmAuthWnd.ShowDialog() == DialogResult.OK)
                        {
                            Code = frmAuthWnd.GetCode;
                            NewCode = frmAuthWnd.GetNewCode;

                            switch (Modem.SimEnterPuk(Code, NewCode))
                            {
                                case MODEM_SIM_PIN_AUTH_STATUS.INCORRECT_PASSWORD:
                                    MessageBox.Show("Incorrect password!");
                                    Modem.Close();
                                    btnConnect.Enabled = true;
                                    btnDisconnect.Enabled = true;
                                    return;
                                case MODEM_SIM_PIN_AUTH_STATUS.INVALID_INPUT_VALUE:
                                    MessageBox.Show("Invalid input value");
                                    Modem.Close();
                                    btnConnect.Enabled = true;
                                    btnDisconnect.Enabled = true;
                                    return;
                            }

                            if (Modem.SimQueryAuthStatus() != MODEM_SIM_PIN_AUTH_STATUS.SIM_READY)
                            {
                                MessageBox.Show("EnterPUK failed");
                                Modem.Close();
                                btnConnect.Enabled = true;
                                btnDisconnect.Enabled = true;
                                return;
                            }
                        }
                        break;

                    case MODEM_SIM_PIN_AUTH_STATUS.CARD_HOLDER_TRAY_REMOVED:
                        tbxPINStatus.Text = "SIM not inserted";
                        Modem.Close();
                        btnConnect.Enabled = true;
                        btnDisconnect.Enabled = true;
                        return;
                }

            }
            
            //if (!ras.Dial(RAS_ENTRY_NAME, m_UserName, m_Password))
            if (!Modem.RasDial(RAS_ENTRY_NAME, m_UserName, m_Password, ras.rasmsgwnd.Hwnd))
            {
                m_bWaitRasEvent = false;
                MessageBox.Show("Ras dial failed", "ModemControl_NET", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
            else
            {
                m_bWaitRasEvent = true;
            }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            if (IsRasConnected())
            {
                Cursor.Current = Cursors.WaitCursor;
                Modem.RasHangUp();
            }
            else
                MessageBox.Show("RAS is not Connected", "ModemControl_NET", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
        }

        private bool IsRasConnected()
        {
            return m_bRasConnected;
        }

        private bool LoadGPRSConfigDataFile()
        {
            bool bRet = false;
            int nError = 0;

            if (!File.Exists(CONFIG_DATA_FILE))
            {
                FormOperator frmOperator = new FormOperator();
                frmOperator.Location = new Point(15, 30);
                if (frmOperator.ShowDialog() == DialogResult.OK)
                {
                    StreamWriter sw = new StreamWriter(CONFIG_DATA_FILE, false, Encoding.Default);
                    sw.WriteLine("[Profile]");
                    sw.WriteLine("File=gprs");
                    sw.WriteLine("CountryName=");
                    sw.WriteLine("ISP=");
                    sw.WriteLine("Providor=");
                    sw.WriteLine("Apn=" + frmOperator.APN);
                    sw.WriteLine("UserName=" + frmOperator.UserName);
                    sw.WriteLine("Password=" + frmOperator.Password);
                    sw.WriteLine("AreaCode=450");
                    sw.WriteLine("RegionCode=1");
                    sw.WriteLine("PhoneNumber=" + frmOperator.PhoneNumber);
                    sw.WriteLine("UseDHCP=1");
                    sw.WriteLine("IPADDR=");
                    sw.WriteLine("PrimaryDNS=");
                    sw.WriteLine("SecondaryDNS=");
                    sw.WriteLine("Local=G");
                    sw.WriteLine("LongDistance=G");
                    sw.WriteLine("International=G");
                    sw.WriteLine("");
                    sw.Close();
                }
                else
                {
                    return bRet;
                }
            }

            StreamReader sr = new StreamReader(CONFIG_DATA_FILE, Encoding.Default);
            while (!sr.EndOfStream)
            {
                string temp = sr.ReadLine();
                if (temp.IndexOf('=') != -1)
                {
                    string[] data = temp.Split("=".ToCharArray());
                    switch (data[0])
                    {
                        case "Apn":
                            m_APN = String.Format("+CGDCONT=1,\"IP\",\"{0}\"", data[1]);
                            break;
                        case "UserName":
                            m_UserName = data[1];
                            break;
                        case "Password":
                            m_Password = data[1];
                            break;
                        case "PhoneNumber":
                            m_PhoneNum = data[1];
                            break;
                        case "Local":
                            m_LocalCall = data[1];
                            break;
                        case "LongDistance":
                            m_LongDistanceCall = data[1];
                            break;
                        case "International":
                            m_InternationalCall = data[1];
                            break;
                    }
                }
            }
            sr.Close();

            
            RAS_TEST.RAS._RASENTRY RasEntry = new RAS_TEST.RAS._RASENTRY();
            RasEntry.dwSize = 3472;
            //RasEntry.dwfOptions = 4194824;
            RasEntry.dwfOptions = RAS_TEST.RAS.RASEO_ProhibitEAP | RAS_TEST.RAS.RASEO_SwCompression | RAS_TEST.RAS.RASEO_IpHeaderCompression;
            RasEntry.dwCountryCode = 82;
            RasEntry.szAreaCode = "2";
            RasEntry.szLocalPhoneNumber = m_PhoneNum;
            RasEntry.dwfNetProtocols = 4;
            RasEntry.dwFramingProtocol = 1;
            RasEntry.szDeviceType = "modem";
            RasEntry.szDeviceName = "HSDPA-MDM";

            byte[] pDevConfig = new byte[104];
            for (int n = 0; n < 104; n++)
                pDevConfig[n] = 0x00;

            pDevConfig[0] = 0x30;
            pDevConfig[4] = 0x05;
            pDevConfig[8] = 0x10;
            pDevConfig[9] = 0x01;
            pDevConfig[13] = 0xC2;
            pDevConfig[14] = 0x01;
            pDevConfig[18] = 0x08;

            int idx = 22;
            if (m_APN.Length != 0)
            {
                foreach (char ch in m_APN)
                {
                    pDevConfig[idx] = Convert.ToByte(ch);
                    idx += 2;
                }
            }

            nError = ras.SetEntryProperties(null, RAS_ENTRY_NAME, ref RasEntry, RasEntry.dwSize, pDevConfig, 104);
            if (nError != 0)
            {
                MessageBox.Show("SetEntryProperties Error:" + nError.ToString());
                bRet = false;
            }
            else
            {
                bRet = true;
            }

            bRet = SetDialingParameters("0", "Work", m_LocalCall, m_LongDistanceCall, m_InternationalCall, "", "", "", "1");
            if (!bRet)
                return bRet;

            bRet = SetDialingParameters("1", "Home", m_LocalCall, m_LongDistanceCall, m_InternationalCall, "", "", "", "1");
            if (!bRet)
                return bRet;

            bRet = SetDialingParameters("2", "Data", m_LocalCall, m_LongDistanceCall, m_InternationalCall, "", "", "", "1");
            if (!bRet)
                return bRet;

            return bRet;
        }

        private void btnHide_Click(object sender, EventArgs e)
        {
            this.Hide();

            bool bRegistered = false;
            if (g_NetworkStatus == MODEM_NETWORK_REGISTRATION_STATUS.REGISTERED_TO_GSM || g_NetworkStatus == MODEM_NETWORK_REGISTRATION_STATUS.REGISTERED_TO_UTRAN)
                bRegistered = true;

            if (bRegistered)
            {
                if (g_NetworkStatus == MODEM_NETWORK_REGISTRATION_STATUS.REGISTERED_TO_GSM)
                {
                    if(m_bRasConnected)
                        m_notifyIcon.Modify(Properties.Resources._2g_ico_on.Handle);
                    else
                        m_notifyIcon.Modify(Properties.Resources._2g_ico_off.Handle);
                }
                else if (g_NetworkStatus == MODEM_NETWORK_REGISTRATION_STATUS.REGISTERED_TO_UTRAN)
                {
                    if(m_bRasConnected)
                        m_notifyIcon.Modify(Properties.Resources._3g_ico_on.Handle);
                    else
                        m_notifyIcon.Modify(Properties.Resources._3g_ico_off.Handle);
                }
            }
            else
            {
                m_notifyIcon.Modify(Properties.Resources.disconnect.Handle);
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (m_bWaitPowerEvent)
            {
                MessageBox.Show("Wait power event...", "ModemControl_NET", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                return;
            }

            if (m_bWaitRasEvent)
            {
                MessageBox.Show("Wait RAS event...", "ModemControl_NET", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                return;
            }
            this.Close();
        }

        private bool SetDialingParameters(string KeyName, string Location, string LocalCalls, string LongDistanceCalls, string InternationalCalls, string AreaCode,
                                            string DisableCallWaitingSequence, string CountryCode, string ToneOrPulse)
        {
            bool bRet = false;
            
            string[] configString = new string[8];
            configString[0] = Location;
            configString[1] = LocalCalls;
            configString[2] = LongDistanceCalls;
            configString[3] = InternationalCalls;
            configString[4] = AreaCode;
            configString[5] = DisableCallWaitingSequence;
            configString[6] = CountryCode;
            configString[7] = ToneOrPulse;

            try
            {
                Registry.SetValue(@"HKEY_CURRENT_USER\Controlpanel\Dial\Locations", KeyName, configString, RegistryValueKind.MultiString);
                bRet = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                bRet = false;
            }

            return bRet;
        }

    }
}
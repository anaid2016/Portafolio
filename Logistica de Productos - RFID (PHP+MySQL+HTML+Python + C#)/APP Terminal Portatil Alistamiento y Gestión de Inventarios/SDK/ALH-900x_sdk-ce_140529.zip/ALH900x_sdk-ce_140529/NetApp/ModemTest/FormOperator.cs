﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.WindowsCE.Forms;

namespace ModemTest
{
    public partial class FormOperator : Form
    {
        InputPanel sip;
        public string APN
        {
            get
            {
                return textBox1.Text.Trim();
            }
        }
        public string UserName
        {
            get
            {
                return textBox2.Text.Trim();
            }
        }
        public string Password
        {
            get
            {
                return textBox3.Text.Trim();
            }
        }
        public string PhoneNumber
        {
            get
            {
                return textBox4.Text.Trim();
            }
        }
        public FormOperator()
        {
            InitializeComponent();

            sip = new InputPanel();
            sip.Enabled = true;

            textBox1.Focus();
        }

        private void FormOperator_Closing(object sender, CancelEventArgs e)
        {
            sip.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        
    }
}
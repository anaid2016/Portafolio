﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ModemTest
{
    public partial class FormPINAuth : Form
    {
        public string GetCode
        {
            get
            {
                return this.textBox1.Text.Trim();
            }
        }

        public string GetNewCode
        {
            get
            {
                return this.textBox2.Text.Trim();
            }
        }

        public FormPINAuth(string CodeType)
        {
            InitializeComponent();

            switch (CodeType)
            {
                case "SIM_PIN":
                    label2.Visible = false;
                    textBox2.Visible = false;
                    break;
                case "SIM_PUK":
                    label1.Text = "Enter PUK Number";
                    label2.Visible = true;
                    textBox2.Visible = true;
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using Microsoft.WindowsCE.Forms;

namespace RAS_TEST
{
   
    public class RAS
    {
        public const uint RASEO_UseCountryAndAreaCodes  = 0x00000001;
        public const uint RASEO_SpecificIpAddr          = 0x00000002;
        public const uint RASEO_SpecificNameServers     = 0x00000004;
        public const uint RASEO_IpHeaderCompression     = 0x00000008;
        public const uint RASEO_RemoteDefaultGateway    = 0x00000010;
        public const uint RASEO_DisableLcpExtensions    = 0x00000020;
        public const uint RASEO_TerminalBeforeDial      = 0x00000040;
        public const uint RASEO_TerminalAfterDial       = 0x00000080;
        public const uint RASEO_ModemLights             = 0x00000100;
        public const uint RASEO_SwCompression           = 0x00000200;
        public const uint RASEO_RequireEncryptedPw      = 0x00000400;
        public const uint RASEO_RequireMsEncryptedPw    = 0x00000800;
        public const uint RASEO_RequireDataEncryption   = 0x00001000;
        public const uint RASEO_NetworkLogon            = 0x00002000;
        public const uint RASEO_UseLogonCredentials     = 0x00004000;
        public const uint RASEO_PromoteAlternates       = 0x00008000;
        public const uint RASEO_SecureLocalFiles        = 0x00010000;
        public const uint RASEO_DialAsLocalCall         = 0x00020000;

        public const uint RASEO_ProhibitPAP             = 0x00040000;
        public const uint RASEO_ProhibitCHAP            = 0x00080000;
        public const uint RASEO_ProhibitMsCHAP          = 0x00100000;
        public const uint RASEO_ProhibitMsCHAP2         = 0x00200000;
        public const uint RASEO_ProhibitEAP             = 0x00400000;
        public const uint RASEO_PreviewUserPw           = 0x01000000;
        public const uint RASEO_NoUserPwRetryDialog     = 0x02000000;
        public const uint RASEO_CustomScript            = 0x80000000;

        internal enum RasFieldSizeConstants
        {
            RAS_MaxDeviceType = 16,
            RAS_MaxPhoneNumber = 128,
            RAS_MaxIpAddress = 15,
            RAS_MaxIpxAddress = 21,
            RAS_MaxEntryName = 20,
            RAS_MaxDeviceName = 32,
            RAS_MaxCallbackNumber = 48,

            RAS_MaxAreaCode = 10,
            RAS_MaxPadType = 32,
            RAS_MaxX25Address = 200,
            RAS_MaxFacilities = 200,
            RAS_MaxUserData = 200,
            RAS_MaxReplyMessage = 1024,
            RAS_MaxDnsSuffix = 256,
            UNLEN = 256,
            PWLEN = 256,
            DNLEN = 15
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public struct RASIPADDR
        {
            byte a;
            byte b;
            byte c;
            byte d;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        public struct _RASENTRY
        {
            public int dwSize;
            public uint dwfOptions;
            //
            // Location/phone number.
            //
            public int dwCountryID;
            public int dwCountryCode;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = (int)RasFieldSizeConstants.RAS_MaxAreaCode + 1)]
            public string szAreaCode;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = (int)RasFieldSizeConstants.RAS_MaxPhoneNumber + 1)]
            public string szLocalPhoneNumber;
            public int dwAlternateOffset;
            //
            // PPP/Ip
            //
            public RASIPADDR ipaddr;
            public RASIPADDR ipaddrDns;
            public RASIPADDR ipaddrDnsAlt;
            public RASIPADDR ipaddrWins;
            public RASIPADDR ipaddrWinsAlt;
            //
            // Framing
            //
            public int dwFrameSize;
            public int dwfNetProtocols;
            public int dwFramingProtocol;
            //
            // Scripting
            //
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]//MAX_PATH
            public string szScript;
            //
            // AutoDial
            //
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]//MAX_PATH
            public string szAutodialDll;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]//MAX_PATH
            public string szAutodialFunc;
            //
            // Device
            //
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = (int)RasFieldSizeConstants.RAS_MaxDeviceType + 1)]
            public string szDeviceType;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = (int)RasFieldSizeConstants.RAS_MaxDeviceName + 1)]
            public string szDeviceName;
            //
            // X.25
            //
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = (int)RasFieldSizeConstants.RAS_MaxPadType + 1)]//MAX_PATH
            public string szX25PadType;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = (int)RasFieldSizeConstants.RAS_MaxX25Address + 1)]//MAX_PATH
            public string szX25Address;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = (int)RasFieldSizeConstants.RAS_MaxFacilities + 1)]//MAX_PATH
            public string szX25Facilities;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = (int)RasFieldSizeConstants.RAS_MaxUserData + 1)]//MAX_PATH
            public string szX25UserData;
            public int dwChannels;
            //
            // Reserved
            //
            public int dwReserved1;
            public int dwReserved2;
            public int dwCustomAuthKey;      // authentication key for EAP
        }

        #region Dll Impport
        //RasGetConnectStatus
        [DllImport("coredll.dll")]
        private static extern uint RasDial(IntPtr dialExtensions, IntPtr phoneBookPath, IntPtr rasDialParam, uint NotifierType, IntPtr notifier, ref IntPtr pRasConn);

        [DllImport("coredll.dll")]
        private static extern uint RasHangUp(IntPtr pRasConn);

        [DllImport("coredll.dll")]
        static extern int RasGetConnectStatus(IntPtr hrasconn, ref RASCONNSTATUS lprasconnstatus);

        [DllImport("coredll.dll")]
        static extern int RasValidateEntryName(string lpszPhonebook, string lpszEntry);

        [DllImport("coredll.dll")]
        static extern int RasSetEntryProperties(string lpszPhoneBook, string lpszEntry, ref _RASENTRY lpRasEntry, int dwEntryInfoSize, byte[] lpbDeviceInfo, int dwDeviceInfoSize);
        //static extern int RasSetEntryProperties(string lpszPhoneBook, string lpszEntry, ref _RASENTRY lpRasEntry, int dwEntryInfoSize, int lpbDeviceInfo, int dwDeviceInfoSize);

        [DllImport("DialingParameters.dll")]
        public static extern int SetDialingParameters(string KeyName,
                            string Location,
                            string LocalCalls,
                            string LongDistanceCalls,
                                string InternationalCalls,
                            string AreaCode,
                            string DisableCallWaitingSequence,
                            string CountryCode,
                            string ToneOrPulse
                            );

        #endregion
        public delegate void RasDialEventHandler(RasConnState RasEventMsg);
        public event RasDialEventHandler GetRasDialEvent;

        internal const int WM_RASDIALEVENT = 0xCCCD;
        const int RAS_MaxDeviceType = 16;
        const int RAS_MaxPhoneNumber = 128;
        const int RAS_MaxDeviceName = 128;
        public enum RasConnState
        {
            RASCS_OpenPort = 0,
            RASCS_PortOpened,
            RASCS_ConnectDevice,
            RASCS_DeviceConnected,
            RASCS_AllDevicesConnected,
            RASCS_Authenticate,
            RASCS_AuthNotify,
            RASCS_AuthRetry,
            RASCS_AuthCallback,
            RASCS_AuthChangePassword,
            RASCS_AuthProject,
            RASCS_AuthLinkSpeed,
            RASCS_AuthAck,
            RASCS_ReAuthenticate,
            RASCS_Authenticated,
            RASCS_PrepareForCallback,
            RASCS_WaitForModemReset,
            RASCS_WaitForCallback,
            RASCS_Projected,

            RASCS_Interactive = 4096,
            RASCS_RetryAuthentication,
            RASCS_CallbackSetByCaller,
            RASCS_PasswordExpired,

            RASCS_Connected = 8192,
            RASCS_Disconnected,

            RASCS_Unknown = 9999
        }
        public RASMsgWnd rasmsgwnd = null;
        public class RASMsgWnd : Microsoft.WindowsCE.Forms.MessageWindow
        {
            private RAS _ras = null;
            public RASMsgWnd(RAS ras)
            {
                this._ras = ras;
            }
            protected override void WndProc(ref Message m)
            {
                switch (m.Msg)
                {
                    case (int)WM_RASDIALEVENT:
                        //_ras.GetRasDialEvent((uint)m.WParam);
                        _ras.GetRasDialEvent(_ras.ParseMSG((int)m.WParam));
                        break;
                    default:
                        break;
                }
                base.WndProc(ref m);
            }
        }

        public RAS()
        {
            rasmsgwnd = new RASMsgWnd(this);
        }
        ~RAS()
        {
            HangUp();
        }
        IntPtr rc; // Ras connection handle

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        struct RASCONNSTATUS
        {
            public int dwSize;
            public int rasconnstate;
            public int dwError;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = RAS_MaxDeviceType + 1)]
            public string szDeviceType;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = RAS_MaxDeviceName + 1)]
            public string szDeviceName;

            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = RAS_MaxPhoneNumber + 1)]
            public string szPhoneNumber;
        }

        unsafe private static uint myRasDial(string EntryName, string UserName, string Password, out IntPtr RasConn, IntPtr hWnd)
        {
            uint r = 0;
            RasConn = IntPtr.Zero;
            byte[] bRASDIALPARAMS = new byte[1464];
            fixed (byte* pAddr = bRASDIALPARAMS)
            {
                byte* pCurrent = pAddr;
                Marshal.WriteInt32((IntPtr)pCurrent, bRASDIALPARAMS.Length);
                pCurrent += 4;
                foreach (byte b in Encoding.Unicode.GetBytes(EntryName))
                {
                    Marshal.WriteByte((IntPtr)pCurrent, b);
                    pCurrent++;
                }
                pCurrent = pAddr + 0x192; //0x192 - offset for RASDIALPARAMS.UserName
                foreach (byte b in Encoding.Unicode.GetBytes(UserName))
                {
                    Marshal.WriteByte((IntPtr)pCurrent, b);
                    pCurrent++;
                }
                pCurrent = pAddr + 0x394; //0x394 - offset for RASDIALPARAMS.Password
                foreach (byte b in Encoding.Unicode.GetBytes(Password))
                {
                    Marshal.WriteByte((IntPtr)pCurrent, b);
                    pCurrent++;
                }
                //r = RasDial(IntPtr.Zero, IntPtr.Zero, (IntPtr)pAddr, 0, IntPtr.Zero, ref RasConn);
                r = RasDial(IntPtr.Zero, IntPtr.Zero, (IntPtr)pAddr, 0xffffffff, hWnd, ref RasConn);
            }
            return r;
        }

        public bool Dial(string EntryName, string UserName, string Password)
        {
            bool rtnval = false;
            uint kc = RAS.myRasDial(EntryName, UserName, Password, out rc, rasmsgwnd.Hwnd);

            if (kc != 0)   // success
            {
                rtnval = false;
            }
            else
            {
                rtnval = true;
            }
            return rtnval;
        }

        public void HangUp()
        {
            RAS.RasHangUp(rc);
        }

        public RasConnState GetConnectionStatus()
        {
            RASCONNSTATUS rcs = new RASCONNSTATUS();
            rcs.dwSize = Marshal.SizeOf(typeof(RASCONNSTATUS));
            RasGetConnectStatus(rc, ref rcs);
            return ParseMSG(rcs.rasconnstate);
        }

        public int ValidateEntryName(string PhoneBook, string Entry)
        {
            return RasValidateEntryName(PhoneBook, Entry);
        }
        public int SetEntryProperties(string PhoneBook, string Entry, ref _RASENTRY RasEntry, int EntryInfoSize, byte[] DeviceInfo, int DeviceInfoSize)
        {
            return RasSetEntryProperties(PhoneBook, Entry, ref RasEntry, EntryInfoSize, DeviceInfo, DeviceInfoSize);
        }
        private RasConnState ParseMSG(int n)
        {
            switch (n)
            {
                case 0:
                    return RasConnState.RASCS_OpenPort;
                case 1:
                    return RasConnState.RASCS_PortOpened;
                case 2:
                    return RasConnState.RASCS_ConnectDevice;
                case 3:
                    return RasConnState.RASCS_DeviceConnected;
                case 4:
                    return RasConnState.RASCS_AllDevicesConnected;
                case 5:
                    return RasConnState.RASCS_Authenticate;
                case 6:
                    return RasConnState.RASCS_AuthNotify;
                case 7:
                    return RasConnState.RASCS_AuthRetry;
                case 8:
                    return RasConnState.RASCS_AuthCallback;
                case 9:
                    return RasConnState.RASCS_AuthChangePassword;
                case 10:
                    return RasConnState.RASCS_AuthProject;
                case 11:
                    return RasConnState.RASCS_AuthLinkSpeed;
                case 12:
                    return RasConnState.RASCS_AuthAck;
                case 13:
                    return RasConnState.RASCS_ReAuthenticate;
                case 14:
                    return RasConnState.RASCS_Authenticated;
                case 15:
                    return RasConnState.RASCS_PrepareForCallback;
                case 16:
                    return RasConnState.RASCS_WaitForModemReset;
                case 17:
                    return RasConnState.RASCS_WaitForCallback;
                case 18:
                    return RasConnState.RASCS_Projected;
                case 4096:
                    return RasConnState.RASCS_Interactive;
                case 4097:
                    return RasConnState.RASCS_RetryAuthentication;
                case 4098:
                    return RasConnState.RASCS_CallbackSetByCaller;
                case 4099:
                    return RasConnState.RASCS_PasswordExpired;
                case 8192:
                    return RasConnState.RASCS_Connected;
                case 8193:
                    return RasConnState.RASCS_Disconnected;
                default:
                    return RasConnState.RASCS_Unknown;
            }

        }

    }
}

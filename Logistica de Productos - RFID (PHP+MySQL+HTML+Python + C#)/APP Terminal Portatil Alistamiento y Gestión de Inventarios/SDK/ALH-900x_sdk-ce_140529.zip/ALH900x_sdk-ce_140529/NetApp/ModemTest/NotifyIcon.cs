using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using Microsoft.WindowsCE.Forms;

namespace ModemTest
{
    public class NotifyIcon
    {
        [DllImport("coredll.dll")]
        static extern uint Shell_NotifyIcon(uint message, ref NOTIFYICONDATA data);

        struct NOTIFYICONDATA
        {
            public int cbSize;
            public IntPtr hWnd;
            public uint uID;
            public uint uFlags;
            public uint uCallbackMessage;
            public IntPtr hIcon;
        }

        private const uint NIM_ADD = 0x00;
        private const uint NIM_MODIFY = 0x01;
        private const uint NIM_DELETE = 0x02;
        private const uint NIF_MESSAGE = 0x01;
        private const uint NIF_ICON = 0x02;
        private const uint NIF_TIP = 0x04;
        private const int WM_USER = 0x0400;
        private const int WM_NOTIFY_TRAY = WM_USER + 0x20D4;//WM_USER + 0x21818;
        private const int WM_LBUTTONDOWN = 0x0201;
        private const int WM_LBUTTONDBLCLK = 0x0203;
        private const int UID = 0;

        private WindowSink m_WndSink = null;

        public delegate void Click();
        public event Click OnClick = null;

        public delegate void DblClick();
        public event DblClick OnDblClick = null;

        private Object m_thisLock = new Object();
        private bool m_isIconOn = false;

        NOTIFYICONDATA notdata;
        

        internal class WindowSink : Microsoft.WindowsCE.Forms.MessageWindow
        {
            //Private members
            private int m_uID = 0;
            private NotifyIcon notifyIcon;
            //Constructor
            public WindowSink(NotifyIcon notIcon)
            {
                notifyIcon = notIcon;
            }

            public int uID
            {
                set
                {
                    m_uID = value;
                }
            }

            protected override void WndProc(ref Message msg)
            {
                if (msg.Msg == WM_NOTIFY_TRAY)
                {
                    switch ((int)msg.LParam)
                    {
                        case WM_LBUTTONDOWN:
                            if ((int)msg.WParam == m_uID)
                            {
                                if (notifyIcon.OnClick != null)
                                    notifyIcon.OnClick();

                            }
                            break;
                        case WM_LBUTTONDBLCLK:
                            if ((int)msg.WParam == m_uID)
                            {
                                System.Diagnostics.Debug.WriteLine("[MDM_APP] WM_LBUTTONDBLCLK");
                                if (notifyIcon.OnDblClick != null)
                                    notifyIcon.OnDblClick();
                            }
                            break;
                    }
                }

            }
        }

        public NotifyIcon()
        {
            
            m_WndSink = new WindowSink(this);
            m_WndSink.uID = UID;

            notdata = new NOTIFYICONDATA();
            notdata.cbSize = 152;
            notdata.hIcon = IntPtr.Zero;// Properties.Resources.disconnect.Handle;
            notdata.hWnd = m_WndSink.Hwnd;
            notdata.uCallbackMessage = WM_NOTIFY_TRAY;
            notdata.uFlags = NIF_MESSAGE | NIF_ICON;
            notdata.uID = UID;

            //Shell_NotifyIcon(NIM_ADD, ref notdata);
        }
        
        private bool TrayMessage(IntPtr hWnd, uint dwMessage, uint uID, IntPtr hIcon)
        {
            uint nRet = 0;
            //NOTIFYICONDATA notdata = new NOTIFYICONDATA();
            /*
            notdata.cbSize = 152;
            notdata.hIcon = hIcon;
            notdata.hWnd = hWnd;
            notdata.uCallbackMessage = WM_NOTIFY_TRAY;
            notdata.uFlags = NIF_MESSAGE | NIF_ICON;
            notdata.uID = uID;
            */
            notdata.hIcon = hIcon;
            nRet = Shell_NotifyIcon(dwMessage, ref notdata);

            return nRet == 0 ? false : true;
        }

        public bool Add(IntPtr hIcon)
        {
            
            bool Rtn = false;

            lock (m_thisLock)
            {
                Rtn = TrayMessage(m_WndSink.Hwnd, NIM_ADD, UID, hIcon);
                if (Rtn)
                    m_isIconOn = true;
            }

            return Rtn;
            
        }
        public bool Remove()
        {
            
            bool Rtn = false;

            lock (m_thisLock)
            {
                Rtn = TrayMessage(m_WndSink.Hwnd, NIM_DELETE, UID, IntPtr.Zero);
                if (Rtn)
                    m_isIconOn = false;
            }

            return Rtn;
            
        }
        public bool Modify(IntPtr hIcon)
        {
            return TrayMessage(m_WndSink.Hwnd, NIM_MODIFY, UID, hIcon);
        }
        public bool isIcon
        {
            get
            {
                lock (m_thisLock)
                {
                    return m_isIconOn;
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace ModemTest
{
    class UnManagedAPI
    {
        [DllImport("coredll.dll")]
        private static extern int PlaySound(string szSound, IntPtr hModule, int flags);

        private enum PlaySoundFlags : int
        {
            SND_SYNC = 0x0,     // play synchronously (default)
            SND_ASYNC = 0x1,    // play asynchronously
            SND_NODEFAULT = 0x2,    // silence (!default) if sound not found
            SND_MEMORY = 0x4,       // pszSound points to a memory file
            SND_LOOP = 0x8,     // loop the sound until next sndPlaySound
            SND_NOSTOP = 0x10,      // don't stop any currently playing sound
            SND_NOWAIT = 0x2000,    // don't wait if the driver is busy
            SND_ALIAS = 0x10000,    // name is a registry alias
            SND_ALIAS_ID = 0x110000,// alias is a predefined ID
            SND_FILENAME = 0x20000, // name is file name
            SND_RESOURCE = 0x40004, // name is resource name or atom
        };
        public static void Play_Sound(string fileName)
        {
            PlaySound(fileName, IntPtr.Zero, (int)(PlaySoundFlags.SND_FILENAME | PlaySoundFlags.SND_ASYNC));
        }
        public static void Play_Sound_NOSTOP(string fileName)
        {
            PlaySound(fileName, IntPtr.Zero, (int)(PlaySoundFlags.SND_FILENAME | PlaySoundFlags.SND_ASYNC | PlaySoundFlags.SND_NOSTOP));
        }

        [DllImport("coredll.dll")]
        static extern uint Shell_NotifyIcon(uint message, ref NOTIFYICONDATA data);

        struct NOTIFYICONDATA
        {
            public int cbSize;
            public IntPtr hWnd;
            public uint uID;
            public uint uFlags;
            public uint uCallbackMessage;
            public IntPtr hIcon;
        }

        private const uint NIM_ADD = 0x00;
        private const uint NIM_MODIFY = 0x01;
        private const uint NIM_DELETE = 0x02;
        private const uint NIF_MESSAGE = 0x01;
        private const uint NIF_ICON = 0x02;
        private const uint NIF_TIP = 0x04;
        private const int WM_USER = 0x0400;
        private const int WM_NOTIFY_TRAY = WM_USER + 0x21818;
        private const int WM_LBUTTONDOWN = 0x0201;
        private const int UID = 21818;

        public const string NETCF_WND_CLASS_NAME = "#NETCF_AGL_BASE_";

        [DllImport("coredll.dll", EntryPoint = "FindWindowW", SetLastError = true)]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("coredll.dll", EntryPoint = "SetForegroundWindow", SetLastError = true)]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("coredll.dll", EntryPoint = "ShowWindow", SetLastError = true)]
        public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        private class SYSTEM_POWER_STATUS_EX2
        {
            public byte ACLineStatus;
            public byte BatteryFlag;
            public byte BatteryLifePercent;
            public byte Reserved1;
            public int BatteryLifeTime;
            public int BatteryFullLifeTime;
            public byte Reserved2;
            public byte BackupBatteryFlag;
            public byte BackupBatteryLifePercent;
            public byte Reserved3;
            public int BackupBatteryLifeTime;
            public int BackupBatteryFullLifeTime;
            public int BatteryVoltage;
            public int BatteryCurrent;
            public int BatteryAverageCurrent;
            public int BatteryAverageInterval;
            public int BatterymAHourConsumed;
            public int BatteryTemperature;
            public int BackupBatteryVoltage;
            public byte BatteryChemistry;
        }

        private const byte BATTERY_FLAG_HIGH = 0x01;
        private const byte BATTERY_FLAG_LOW = 0x02;
        private const byte BATTERY_FLAG_CRITICAL = 0x04;
        private const byte BATTERY_FLAG_CHARGING = 0x08;
        private const byte BATTERY_FLAG_NO_BATTERY = 0x80;
        private const byte BATTERY_FLAG_UNKNOWN = 0xFF;

        [DllImport("coredll.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.U4)]
        private static extern int GetSystemPowerStatusEx2(SYSTEM_POWER_STATUS_EX2 pSystemPowerStatusEx2, [MarshalAs(UnmanagedType.U4), In] int dwLen, [MarshalAs(UnmanagedType.Bool), In] bool fUpdate);


        public static bool DetectBattery
        {
            get
            {
                SYSTEM_POWER_STATUS_EX2 status = new SYSTEM_POWER_STATUS_EX2();
                if (GetSystemPowerStatusEx2(status, Marshal.SizeOf(status), true) > 0)
                {
                    if (status.BatteryFlag == BATTERY_FLAG_HIGH || status.BatteryFlag == BATTERY_FLAG_LOW || status.BatteryFlag == BATTERY_FLAG_CHARGING)
                        return true;
                    else
                        return false;
                }
                else
                    return false;
            }
        }
    }
}

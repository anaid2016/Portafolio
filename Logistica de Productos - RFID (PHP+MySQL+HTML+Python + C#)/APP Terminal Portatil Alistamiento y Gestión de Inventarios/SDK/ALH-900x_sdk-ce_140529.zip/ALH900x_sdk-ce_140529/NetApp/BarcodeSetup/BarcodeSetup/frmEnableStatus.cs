﻿using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using NBarcodeApi;
using System.Runtime.InteropServices;

namespace BarcodeSetup
{
    public partial class frmEnableStatus : Form
    {
        NBarcodeApi.N2DSymbols.CONFIG_2DSWD_OCR cfgOCR;
        NBarcodeApi.SYMBOL_CONFIG SymConfig;

        public frmEnableStatus()
        {
            InitializeComponent();

            LoadEnableStatus();
        }

        public void LoadEnableStatus()
        {
            Cursor.Current = Cursors.WaitCursor;
            this.Enabled = false;

            int nMax = frmMain.Enable2DFunctions ? (int)NBarcodeApi.N2DSymbols.SYMBOLOGIES_2DSWD.NUM_OF_2DSWD_SYMBOLOGIES :
                                                   (int)NBarcodeApi.N1DSymbols.SYMBOLOGIES_1D.NUM_OF_1D_SYMBOLOGIES;
            NBarcodeApi.N1DSymbols.SYMBOLOGIES_1D Symbol1D;
            NBarcodeApi.N2DSymbols.SYMBOLOGIES_2DSWD Symbol2D;

            bool[] SymbolTable = new bool[nMax];
            BARCODE_RESULT result = frmMain.barcode.GetEnableStateAll(ref SymbolTable);
            System.Diagnostics.Debug.WriteLine(result.ToString());

            for (int i = 0; i < nMax; i++)
            {
                ListViewItem item = new ListViewItem();

                if (frmMain.Enable2DFunctions)
                {
                    Symbol2D = (NBarcodeApi.N2DSymbols.SYMBOLOGIES_2DSWD)i;
                    item.Text = (string)frmMain.ht2DSymbolName[Symbol2D];//Symbol2D.ToString().Replace("SYMBOL_2DSWD_", "");
                }
                else
                {
                    Symbol1D = (NBarcodeApi.N1DSymbols.SYMBOLOGIES_1D)i;
                    item.Text = Symbol1D.ToString().Replace("SYMBOL_1D_", "");
                }

                
                item.Checked = SymbolTable[i];

                // 2012.12.05 yjcho
                if ((int)NBarcodeApi.N2DSymbols.SYMBOLOGIES_2DSWD.SYMBOL_2DSWD_OCR == i)
                {
                    cfgOCR = new NBarcodeApi.N2DSymbols.CONFIG_2DSWD_OCR();
                    SymConfig = new SYMBOL_CONFIG();
                    SymConfig.Symbol = (int)NBarcodeApi.N2DSymbols.SYMBOLOGIES_2DSWD.SYMBOL_2DSWD_OCR;
                    SymConfig.pConfigData = Marshal.AllocHGlobal(Marshal.SizeOf(cfgOCR));
                    frmMain.barcode.GetSymbologyConfig(ref SymConfig);

                    cfgOCR = (NBarcodeApi.N2DSymbols.CONFIG_2DSWD_OCR)Marshal.PtrToStructure(SymConfig.pConfigData, typeof(NBarcodeApi.N2DSymbols.CONFIG_2DSWD_OCR));
                    switch (cfgOCR.nFont)
                    {
                        case NBarcodeApi.N2DSymbols.OCRMode.OCRMODE_A:
                        case NBarcodeApi.N2DSymbols.OCRMode.OCRMODE_B:
                        case NBarcodeApi.N2DSymbols.OCRMode.OCRMODE_MONEY:
                            item.Checked = true;
                            break;
                        default:
                            item.Checked = false;
                            break;
                    }

                    

                    Marshal.FreeHGlobal(SymConfig.pConfigData);
                    SymConfig.pConfigData = IntPtr.Zero;
                }

                listView1.Items.Add(item);
            }

            this.Enabled = true;
            Cursor.Current = Cursors.Default;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool[] EnabledSymbolTable = null;
            bool[] DisabledSymbolTable = null;
            int nIdx = 0;

            if (frmMain.Enable2DFunctions)
            {
                EnabledSymbolTable = new bool[(int)NBarcodeApi.N2DSymbols.SYMBOLOGIES_2DSWD.NUM_OF_2DSWD_SYMBOLOGIES];
                DisabledSymbolTable = new bool[(int)NBarcodeApi.N2DSymbols.SYMBOLOGIES_2DSWD.NUM_OF_2DSWD_SYMBOLOGIES];
            }
            else
            {
                EnabledSymbolTable = new bool[(int)NBarcodeApi.N1DSymbols.SYMBOLOGIES_1D.NUM_OF_1D_SYMBOLOGIES];
                DisabledSymbolTable = new bool[(int)NBarcodeApi.N1DSymbols.SYMBOLOGIES_1D.NUM_OF_1D_SYMBOLOGIES];
            }

            foreach (ListViewItem item in listView1.Items)
            {               
                EnabledSymbolTable[nIdx] = item.Checked;
                DisabledSymbolTable[nIdx++] = !item.Checked;
            }

            Cursor.Current = Cursors.WaitCursor;
            BARCODE_RESULT result = frmMain.barcode.EnableSymbologies(EnabledSymbolTable);
            if (result != BARCODE_RESULT.BARCODE_RESULT_SUCCESS)
            {
                Cursor.Current = Cursors.Default;
                UnmanagedAPI.PlaySound(@"\Windows\Fail.wav");
                MessageBox.Show("EnableSymbologies: " + result.ToString());
                return;
            }

            result = frmMain.barcode.DisableSymbologies(DisabledSymbolTable);
            if (result != BARCODE_RESULT.BARCODE_RESULT_SUCCESS)
            {
                Cursor.Current = Cursors.Default;
                UnmanagedAPI.PlaySound(@"\Windows\Fail.wav");
                MessageBox.Show("DisableSymbologies: " + result.ToString());
                return;
            }

            // 2012.12.05 yjcho
            if (frmMain.Enable2DFunctions)
            {
                bool OCRCurrentEnabledState = false;

                if (cfgOCR.nFont == NBarcodeApi.N2DSymbols.OCRMode.OCRMODE_A || cfgOCR.nFont == NBarcodeApi.N2DSymbols.OCRMode.OCRMODE_B || cfgOCR.nFont == NBarcodeApi.N2DSymbols.OCRMode.OCRMODE_MONEY)
                    OCRCurrentEnabledState = true;

                if (EnabledSymbolTable[(int)NBarcodeApi.N2DSymbols.SYMBOLOGIES_2DSWD.SYMBOL_2DSWD_OCR] != OCRCurrentEnabledState)
                {
                    if (OCRCurrentEnabledState)
                        cfgOCR.nFont = NBarcodeApi.N2DSymbols.OCRMode.OCRMODE_DISABLED;
                    else
                        cfgOCR.nFont = NBarcodeApi.N2DSymbols.OCRMode.OCRMODE_A;

                    SymConfig = new NBarcodeApi.SYMBOL_CONFIG();
                    SymConfig.Symbol = (int)NBarcodeApi.N2DSymbols.SYMBOLOGIES_2DSWD.SYMBOL_2DSWD_OCR;

                    SymConfig.pConfigData = Marshal.AllocHGlobal(Marshal.SizeOf(cfgOCR));
                    Marshal.StructureToPtr(cfgOCR, SymConfig.pConfigData, false);

                    frmMain.barcode.SetSymbologyConfig(SymConfig);
                    Marshal.FreeHGlobal(SymConfig.pConfigData);
                    SymConfig.pConfigData = IntPtr.Zero;
                }
            }

            Cursor.Current = Cursors.Default;
            UnmanagedAPI.PlaySound(@"\Windows\Success.wav");
        }
    }
}
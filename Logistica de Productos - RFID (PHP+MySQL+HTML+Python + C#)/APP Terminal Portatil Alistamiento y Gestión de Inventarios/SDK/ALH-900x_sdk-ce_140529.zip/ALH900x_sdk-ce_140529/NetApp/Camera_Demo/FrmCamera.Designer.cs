﻿namespace Camera_Demo
{
    partial class Camera
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.picCamImage = new System.Windows.Forms.PictureBox();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnCapture = new System.Windows.Forms.Button();
            this.cmbImgMode = new System.Windows.Forms.ComboBox();
            this.btnSetEffection = new System.Windows.Forms.Button();
            this.cmbEffection = new System.Windows.Forms.ComboBox();
            this.cmbFlash = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // picCamImage
            // 
            this.picCamImage.Location = new System.Drawing.Point(0, 0);
            this.picCamImage.Name = "picCamImage";
            this.picCamImage.Size = new System.Drawing.Size(230, 194);
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(0, 197);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(87, 20);
            this.btnOpen.TabIndex = 1;
            this.btnOpen.Text = "Start Preview";
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(87, 197);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(87, 20);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "StopPreview";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnCapture
            // 
            this.btnCapture.Location = new System.Drawing.Point(0, 220);
            this.btnCapture.Name = "btnCapture";
            this.btnCapture.Size = new System.Drawing.Size(110, 20);
            this.btnCapture.TabIndex = 1;
            this.btnCapture.Text = "Capture";
            this.btnCapture.Click += new System.EventHandler(this.btnCapture_Click);
            // 
            // cmbImgMode
            // 
            this.cmbImgMode.Location = new System.Drawing.Point(0, 243);
            this.cmbImgMode.Name = "cmbImgMode";
            this.cmbImgMode.Size = new System.Drawing.Size(110, 23);
            this.cmbImgMode.TabIndex = 3;
            // 
            // btnSetEffection
            // 
            this.btnSetEffection.Location = new System.Drawing.Point(120, 220);
            this.btnSetEffection.Name = "btnSetEffection";
            this.btnSetEffection.Size = new System.Drawing.Size(110, 20);
            this.btnSetEffection.TabIndex = 5;
            this.btnSetEffection.Text = "Set Effect";
            this.btnSetEffection.Click += new System.EventHandler(this.btnWhite_Click);
            // 
            // cmbEffection
            // 
            this.cmbEffection.Items.Add("WhiteBalance");
            this.cmbEffection.Items.Add("Contrast");
            this.cmbEffection.Items.Add("Saturation");
            this.cmbEffection.Items.Add("Brightness");
            this.cmbEffection.Items.Add("Effect");
            this.cmbEffection.Items.Add("Flip");
            this.cmbEffection.Items.Add("AutoFocus");
            this.cmbEffection.Location = new System.Drawing.Point(120, 243);
            this.cmbEffection.Name = "cmbEffection";
            this.cmbEffection.Size = new System.Drawing.Size(110, 23);
            this.cmbEffection.TabIndex = 7;
            // 
            // cmbFlash
            // 
            this.cmbFlash.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.cmbFlash.Items.Add("FlashOff");
            this.cmbFlash.Items.Add("FlashOn");
            this.cmbFlash.Location = new System.Drawing.Point(175, 197);
            this.cmbFlash.Name = "cmbFlash";
            this.cmbFlash.Size = new System.Drawing.Size(55, 19);
            this.cmbFlash.TabIndex = 9;
            this.cmbFlash.SelectedIndexChanged += new System.EventHandler(this.cmbFlash_SelectedIndexChanged);
            // 
            // Camera
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(638, 455);
            this.Controls.Add(this.cmbFlash);
            this.Controls.Add(this.cmbEffection);
            this.Controls.Add(this.btnSetEffection);
            this.Controls.Add(this.cmbImgMode);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCapture);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.picCamImage);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Camera";
            this.Text = "Camera";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Closed += new System.EventHandler(this.Camera_Closed);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.Camera_Closing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picCamImage;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnCapture;
        private System.Windows.Forms.ComboBox cmbImgMode;
        private System.Windows.Forms.Button btnSetEffection;
        private System.Windows.Forms.ComboBox cmbEffection;
        private System.Windows.Forms.ComboBox cmbFlash;
    }
}


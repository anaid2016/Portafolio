﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Camera_Demo")]
[assembly: AssemblyDescription("A Camera demo application.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Camera Demo Application")]
[assembly: AssemblyCopyright("Copyright © 2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("b78481d4-8d0c-49c8-beec-4ee981b9467a")]

[assembly: AssemblyVersion("14.05.29.0")]


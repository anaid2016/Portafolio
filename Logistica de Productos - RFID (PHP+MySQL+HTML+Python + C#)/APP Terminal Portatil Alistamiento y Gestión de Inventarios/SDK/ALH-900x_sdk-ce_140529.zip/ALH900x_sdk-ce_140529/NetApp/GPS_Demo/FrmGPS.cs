﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using NGpsApi;

namespace GPS_Demo
{
    public partial class frmGps : Form
    {
        // NGpsApi Dll Class Object. 
        GpsApi gps;        

        public frmGps()
        {
            InitializeComponent();

            // Declaration.
            gps = new GpsApi();

            //=======================================================
            // When GPS data is received to register a callback
            // function to retrieve the data should.
            gps.SetCallBack(new GpsApi.GPSCALLBACK(GpsAppCallBack));
        }

        //===========================================================
        // The callback function is Called When
        // data is received.
        void GpsAppCallBack(string sData)
        {
            //GPS NMEA data output value in listview Control.
            lsbRead.Items.Add(sData);
            lsbRead.SelectedIndex = lsbRead.Items.Count - 1;
        }
       
        private void btnOpen_Click(object sender, EventArgs e)
        {
            GPS_RESULT res;

            // ========================================================
            // 1. is the power of GPS device and is initialized.
            // 2. if successful, will return to GPS_RSULT_SUCCESS.
            if ((res = gps.Open(PORT.COM6, BAUDRATE.BR_9600)) != GPS_RESULT.GPS_RESULT_SUCCESS)
                MessageBox.Show("It is failed to open GPS module : " + res.ToString());

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            // ========================================================
            // GPS devices to remove the power to release the assigned resource.
            gps.Close();
        }
    }
}
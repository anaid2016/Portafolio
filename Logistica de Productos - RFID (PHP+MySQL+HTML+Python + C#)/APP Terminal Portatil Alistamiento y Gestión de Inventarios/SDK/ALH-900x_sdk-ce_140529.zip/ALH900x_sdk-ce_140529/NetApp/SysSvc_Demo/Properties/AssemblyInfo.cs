﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SysSvc_Demo")]
[assembly: AssemblyDescription("A System service demo application.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SysSvc Demo Application")]
[assembly: AssemblyCopyright("Copyright © 2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("a92adc4b-c091-4129-b1fe-741122736aae")]

[assembly: AssemblyVersion("14.05.29.0")]


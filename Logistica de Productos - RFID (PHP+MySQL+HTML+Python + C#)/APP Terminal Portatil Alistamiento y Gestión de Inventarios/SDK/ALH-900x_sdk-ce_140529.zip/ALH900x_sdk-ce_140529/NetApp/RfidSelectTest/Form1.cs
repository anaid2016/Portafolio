﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Collections;
using System.Runtime.InteropServices;
using NRfidApi;

namespace SelectTest
{
    public partial class Form1 : Form
    {
        ArrayList Tags = new ArrayList();
        RfidApi rfid;
        RFIDSELMASKPARAMS_EX[] Masks = new RFIDSELMASKPARAMS_EX[255];
        Hashtable SelParams = new Hashtable();
        
        const int BitsPerByte = 8;

        public Form1()
        {
            InitializeComponent();
            this.Text = "SelectTest";

            numericUpDown1.Minimum = 0;
            numericUpDown1.Maximum = 255;

            Cursor.Current = Cursors.WaitCursor;
            rfid = new RfidApi();
            rfid.PowerOn();
            if (rfid.Open() != RFID_RESULT.RFID_RESULT_SUCCESS)
            {
                MessageBox.Show("rfid Open failed");
                rfid.PowerOff();
                Application.Exit();
            }

            rfid.SetCallback(new RfidCallbackProc(CallbackProc));
            rfid.PowerLevel = 20;

            switch (rfid.Session)
            {
                case SESSION_TYPE.SESSION_0:
                    comboBox1.SelectedIndex = 0;
                    break;
                case SESSION_TYPE.SESSION_1:
                    comboBox1.SelectedIndex = 1;
                    break;
                case SESSION_TYPE.SESSION_2:
                    comboBox1.SelectedIndex = 2;
                    break;
                case SESSION_TYPE.SESSION_3:
                    comboBox1.SelectedIndex = 3;
                    break;
            }

            switch (rfid.InventoryTarget)
            {
                case INVENTORIED_STATE.STATE_A:
                    comboBox2.SelectedIndex = 0;
                    break;
                case INVENTORIED_STATE.STATE_B:
                    comboBox2.SelectedIndex = 1;
                    break;
                case INVENTORIED_STATE.STATE_AB:
                    comboBox2.SelectedIndex = 2;
                    break;
            }
            Cursor.Current = Cursors.Default;
        }

        private void Form1_Closing(object sender, CancelEventArgs e)
        {
            if (rfid.IsOpen())
                rfid.Close();

            rfid.PowerOff();
        }

        public void CallbackProc(RFIDCALLBACKDATA CallbackData)
        {
            string Msg = new string(new char[512]);
            rfid.GetResult(Msg, CallbackData.CallbackType, CallbackData.wParam, CallbackData.lParam);
            Msg = Msg.Substring(0, Msg.IndexOf("\0"));

            if (CallbackData.CallbackType == RFID_CALLBACK_TYPE.RFIDCALLBACKTYPE_DATA)
            {
                if (Tags.Contains(Msg))
                {
                    foreach (ListViewItem item in listView1.Items)
                    {
                        if (item.SubItems[0].Text.Equals(Msg))
                        {
                            item.SubItems[1].Text = Convert.ToString(Convert.ToInt32(item.SubItems[1].Text) + 1);
                            break;
                        }
                    }
                }
                else
                {
                    ListViewItem item = new ListViewItem(Msg);
                    item.SubItems.Add("1");
                    int count = listView1.Items.Count;
                    if (count == 0 || count % 2 == 0)
                        item.BackColor = Color.LightCyan;
                    else
                        item.BackColor = Color.AntiqueWhite;
                    listView1.Items.Add(item);
                    Tags.Add(Msg);
                    label2.Text = Tags.Count.ToString();
                }

                //Play_Sound_NOSTOP(@"\Windows\Success.wav");
            }
            else if (CallbackData.CallbackType == RFID_CALLBACK_TYPE.RFIDCALLBACKTYPE_REPLY)
            {
                
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
#if true

            System.Diagnostics.Debug.WriteLine(String.Format("NumberOfSelect : {0}", rfid.Selects.ToString()));
            ArrayList sorter = new ArrayList(SelParams.Keys);
            sorter.Sort();

            int idx = 0;
            foreach (int Key in sorter)
            {
                Masks[idx++] = (RFIDSELMASKPARAMS_EX)SelParams[Key];
            }

            RFID_RESULT result = rfid.ReadEpcEx(false, RFID_READ_TYPE.EPC_GEN2_MULTI_TAG, Masks, (uint)Masks.Length, null);
            System.Diagnostics.Debug.WriteLine("ReadEpcEx : " + result.ToString());
#else
            rfid.Selects = 1;
            RFIDSELMASKPARAMS_EX[] temp = new RFIDSELMASKPARAMS_EX[10];
            temp[0].SelectTarget = SELECT_TARGET.S3;
            temp[0].ActionCode = SELECT_ACTION.ACTION_0;
            temp[0].MemBank = MEM_BANK.EPC;
            temp[0].OffSet = 120;
            temp[0].Bits = 8;
            temp[0].MaskPattern = new byte[RfidApi.MAX_MASK_BYTES];
            temp[0].MaskPattern[0] = 0x04;

            RFID_RESULT result = rfid.ReadEpcEx(false, RFID_READ_TYPE.EPC_GEN2_MULTI_TAG, null, 0, null);
            System.Diagnostics.Debug.WriteLine("[TEST] ReadEpcEx, " + result.ToString());
            //rfid.ReadEpcEx(false, RFID_READ_TYPE.EPC_GEN2_MULTI_TAG, null, 0, null);
#endif

            Array.Clear(Masks, 0, Masks.Length);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            rfid.Stop();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            Tags.Clear();
            label2.Text = "0";
        }

        private void checkBox1_CheckStateChanged(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 dlg = new Form2();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                RFIDSELMASKPARAMS_EX param = dlg.param;

                ListViewItem item = new ListViewItem(param.SelectTarget.ToString());
                item.SubItems.Add(param.ActionCode.ToString().Replace("ACTION", "ACT"));
                item.SubItems.Add(param.MemBank.ToString());
                item.SubItems.Add(param.OffSet.ToString());
                item.SubItems.Add(param.Bits.ToString());
                string strPattern = String.Empty;

                int nLoop = (int)param.Bits / BitsPerByte;
                if (param.Bits % BitsPerByte != 0)
                    nLoop++;

                for (int i = 0; i < nLoop; i++)
                {
                    strPattern += param.MaskPattern[i].ToString("X2");
                }

                item.SubItems.Add(strPattern);

                int nKey = Environment.TickCount;
                item.SubItems.Add(nKey.ToString());
                listView2.Items.Add(item);
                SelParams.Add(nKey, param);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (listView2.SelectedIndices.Count > 0)
            {
                int idx = listView2.SelectedIndices[0];
                int key = Convert.ToInt32(listView2.Items[idx].SubItems[6].Text);
                listView2.Items.RemoveAt(idx);
                SelParams.Remove(key);
                
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SESSION_TYPE Session = SESSION_TYPE.SESSION_0;
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    Session = SESSION_TYPE.SESSION_0;
                    break;
                case 1:
                    Session = SESSION_TYPE.SESSION_1;
                    break;
                case 2:
                    Session = SESSION_TYPE.SESSION_2;
                    break;
                case 3:
                    Session = SESSION_TYPE.SESSION_3;
                    break;
            }

            rfid.Session = Session;
            if (rfid.Session != Session)
                MessageBox.Show("Failed");
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            INVENTORIED_STATE InvState = INVENTORIED_STATE.STATE_A;
            switch (comboBox2.SelectedIndex)
            {
                case 0:
                    InvState = INVENTORIED_STATE.STATE_A;
                    break;
                case 1:
                    InvState = INVENTORIED_STATE.STATE_B;
                    break;
                case 2:
                    InvState = INVENTORIED_STATE.STATE_AB;
                    break;
            }

            rfid.InventoryTarget = InvState;
            if (rfid.InventoryTarget != InvState)
                MessageBox.Show("Failed");
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            rfid.Selects = (int)numericUpDown1.Value;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            rfid.ReadEpcEx(false, RFID_READ_TYPE.EPC_GEN2_MULTI_TAG, null);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine(String.Format("NumberOfSelect : {0}", rfid.Selects.ToString()));
            ArrayList sorter = new ArrayList(SelParams.Keys);
            sorter.Sort();

            int idx = 0;
            foreach (int Key in sorter)
            {
                Masks[idx++] = (RFIDSELMASKPARAMS_EX)SelParams[Key];
            }

            RFID_RESULT result = rfid.ReadMemBankEx(false, MEM_BANK.EPC, 7, 1, false, null, Masks, (uint)Masks.Length, null);
            System.Diagnostics.Debug.WriteLine("ReadMemBankEx : " + result.ToString());

            Array.Clear(Masks, 0, Masks.Length);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            RFID_RESULT result = rfid.ReadEpc(false, RFID_READ_TYPE.EPC_GEN2_MULTI_TAG, null);
            System.Diagnostics.Debug.WriteLine("ReadEpc : " + result.ToString());
        }
    }
}
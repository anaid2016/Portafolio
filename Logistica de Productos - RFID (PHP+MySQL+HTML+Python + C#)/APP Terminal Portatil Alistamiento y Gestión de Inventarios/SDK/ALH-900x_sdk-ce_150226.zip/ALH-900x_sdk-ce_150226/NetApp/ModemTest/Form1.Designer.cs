﻿namespace ModemTest
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbxModemStatus = new System.Windows.Forms.ListBox();
            this.btnPowerUp = new System.Windows.Forms.Button();
            this.btnPowerDown = new System.Windows.Forms.Button();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.lbxRasStatus = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbxPINStatus = new System.Windows.Forms.TextBox();
            this.btnHide = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label1.Location = new System.Drawing.Point(3, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 16);
            this.label1.Text = "Modem Status";
            // 
            // lbxModemStatus
            // 
            this.lbxModemStatus.Location = new System.Drawing.Point(5, 24);
            this.lbxModemStatus.Name = "lbxModemStatus";
            this.lbxModemStatus.Size = new System.Drawing.Size(227, 66);
            this.lbxModemStatus.TabIndex = 1;
            // 
            // btnPowerUp
            // 
            this.btnPowerUp.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.btnPowerUp.Location = new System.Drawing.Point(5, 92);
            this.btnPowerUp.Name = "btnPowerUp";
            this.btnPowerUp.Size = new System.Drawing.Size(113, 28);
            this.btnPowerUp.TabIndex = 2;
            this.btnPowerUp.Text = "Power Up";
            this.btnPowerUp.Click += new System.EventHandler(this.btnPowerUp_Click);
            // 
            // btnPowerDown
            // 
            this.btnPowerDown.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.btnPowerDown.Location = new System.Drawing.Point(119, 92);
            this.btnPowerDown.Name = "btnPowerDown";
            this.btnPowerDown.Size = new System.Drawing.Size(113, 28);
            this.btnPowerDown.TabIndex = 3;
            this.btnPowerDown.Text = "Power Down";
            this.btnPowerDown.Click += new System.EventHandler(this.btnPowerDown_Click);
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.btnDisconnect.Location = new System.Drawing.Point(118, 229);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(115, 28);
            this.btnDisconnect.TabIndex = 7;
            this.btnDisconnect.Text = "RAS Disconnect";
            this.btnDisconnect.Click += new System.EventHandler(this.btnDisconnect_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.btnConnect.Location = new System.Drawing.Point(6, 229);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(111, 28);
            this.btnConnect.TabIndex = 6;
            this.btnConnect.Text = "RAS Connect";
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // lbxRasStatus
            // 
            this.lbxRasStatus.Location = new System.Drawing.Point(6, 161);
            this.lbxRasStatus.Name = "lbxRasStatus";
            this.lbxRasStatus.Size = new System.Drawing.Size(227, 66);
            this.lbxRasStatus.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label2.Location = new System.Drawing.Point(4, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 16);
            this.label2.Text = "RAS Status";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label3.Location = new System.Drawing.Point(41, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 16);
            this.label3.Text = "PIN Authentication";
            // 
            // tbxPINStatus
            // 
            this.tbxPINStatus.Location = new System.Drawing.Point(137, 123);
            this.tbxPINStatus.Name = "tbxPINStatus";
            this.tbxPINStatus.Size = new System.Drawing.Size(95, 23);
            this.tbxPINStatus.TabIndex = 11;
            // 
            // btnHide
            // 
            this.btnHide.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.btnHide.Location = new System.Drawing.Point(5, 258);
            this.btnHide.Name = "btnHide";
            this.btnHide.Size = new System.Drawing.Size(111, 28);
            this.btnHide.TabIndex = 15;
            this.btnHide.Text = "Hide";
            this.btnHide.Click += new System.EventHandler(this.btnHide_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.btnExit.Location = new System.Drawing.Point(118, 258);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(115, 28);
            this.btnExit.TabIndex = 16;
            this.btnExit.Text = "Exit";
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(238, 288);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnHide);
            this.Controls.Add(this.tbxPINStatus);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnDisconnect);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.lbxRasStatus);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnPowerDown);
            this.Controls.Add(this.btnPowerUp);
            this.Controls.Add(this.lbxModemStatus);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lbxModemStatus;
        private System.Windows.Forms.Button btnPowerUp;
        private System.Windows.Forms.Button btnPowerDown;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.ListBox lbxRasStatus;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbxPINStatus;
        private System.Windows.Forms.Button btnHide;
        private System.Windows.Forms.Button btnExit;
    }
}


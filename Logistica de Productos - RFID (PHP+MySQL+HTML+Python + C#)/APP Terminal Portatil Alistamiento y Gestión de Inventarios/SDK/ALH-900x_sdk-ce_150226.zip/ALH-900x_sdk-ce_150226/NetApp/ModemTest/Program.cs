﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace ModemTest
{
    static class Program
    {
        [MTAThread]
        static void Main()
        {
            IntPtr hWnd = UnManagedAPI.FindWindow(UnManagedAPI.NETCF_WND_CLASS_NAME, "ModemControl_NET");
            if (hWnd != IntPtr.Zero)
            {
                UnManagedAPI.ShowWindow(hWnd, 5);
                UnManagedAPI.SetForegroundWindow(hWnd);
                return;
            }

            Application.Run(new Form1());
        }
    }
}
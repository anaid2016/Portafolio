﻿namespace Bluetooth_Demo
{
    partial class FrmBluetooth
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form

        private void InitializeComponent()
        {
            this.rbtnOn = new System.Windows.Forms.RadioButton();
            this.rbtnOff = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // rbtnOn
            // 
            this.rbtnOn.Location = new System.Drawing.Point(72, 64);
            this.rbtnOn.Name = "rbtnOn";
            this.rbtnOn.Size = new System.Drawing.Size(97, 32);
            this.rbtnOn.TabIndex = 0;
            this.rbtnOn.Text = "Power On";
            this.rbtnOn.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // rbtnOff
            // 
            this.rbtnOff.Checked = true;
            this.rbtnOff.Location = new System.Drawing.Point(72, 102);
            this.rbtnOff.Name = "rbtnOff";
            this.rbtnOff.Size = new System.Drawing.Size(97, 32);
            this.rbtnOff.TabIndex = 1;
            this.rbtnOff.Text = "Power Off";
            // 
            // FrmBluetooth
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(238, 270);
            this.Controls.Add(this.rbtnOff);
            this.Controls.Add(this.rbtnOn);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmBluetooth";
            this.Text = "Bluetooth";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton rbtnOn;
        private System.Windows.Forms.RadioButton rbtnOff;

    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using NBluetoothApi;

namespace Bluetooth_Demo
{

    public partial class FrmBluetooth : Form
    {

        // NBluetoothApi Dll Class Object. 
        BluetoothApi bt;

        public FrmBluetooth()
        {
            InitializeComponent();

            bt = new BluetoothApi();

            bool pwr = false;
            bt.GetPowerEnable(ref pwr);

            if (pwr)
                rbtnOn.Checked = true;
        }

        private void radioButton_CheckedChanged(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            bool pwr = false;
            bt.GetPowerEnable(ref pwr);
            if (rbtnOn.Checked)
            {
                if (!pwr)
                    bt.PowerEnable(true);
            }
            else
            {
                if (pwr)
                    bt.PowerEnable(false);
            }
            Cursor.Current = Cursors.Default;
        }

    }
}
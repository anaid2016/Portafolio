﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Bluetooth_Demo")]
[assembly: AssemblyDescription("A Bluetooth demo application.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Bluetooth Demo Application")]
[assembly: AssemblyCopyright("Copyright © 2015")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("58a127ab-261c-4155-bd82-16c9615070bd")]

[assembly: AssemblyVersion("15.02.05.0")]


﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GPS_Demo")]
[assembly: AssemblyDescription("A GPS demo application.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("GPS Demo Application")]
[assembly: AssemblyCopyright("Copyright © 2015")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("64fdc0ea-0e8f-47ff-aba6-f5d6987bbe37")]

[assembly: AssemblyVersion("15.02.05.0")]


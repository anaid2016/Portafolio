﻿namespace KeyEventNotifyTest
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form

        private void InitializeComponent()
        {
            this.btnSubscribe = new System.Windows.Forms.Button();
            this.btnUnsubscribe = new System.Windows.Forms.Button();
            this.listEvents = new System.Windows.Forms.ListBox();
            this.lblInstructions = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSubscribe
            // 
            this.btnSubscribe.Location = new System.Drawing.Point(20, 44);
            this.btnSubscribe.Name = "btnSubscribe";
            this.btnSubscribe.Size = new System.Drawing.Size(88, 34);
            this.btnSubscribe.TabIndex = 0;
            this.btnSubscribe.Text = "Subscribe";
            this.btnSubscribe.Click += new System.EventHandler(this.buttonSubscribe_Click);
            // 
            // btnUnsubscribe
            // 
            this.btnUnsubscribe.Location = new System.Drawing.Point(135, 44);
            this.btnUnsubscribe.Name = "btnUnsubscribe";
            this.btnUnsubscribe.Size = new System.Drawing.Size(88, 34);
            this.btnUnsubscribe.TabIndex = 1;
            this.btnUnsubscribe.Text = "Unsubscribe";
            this.btnUnsubscribe.Click += new System.EventHandler(this.buttonUnsubscribe_Click);
            // 
            // listEvents
            // 
            this.listEvents.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.listEvents.Location = new System.Drawing.Point(20, 84);
            this.listEvents.Name = "listEvents";
            this.listEvents.Size = new System.Drawing.Size(203, 184);
            this.listEvents.TabIndex = 2;
            // 
            // lblInstructions
            // 
            this.lblInstructions.Location = new System.Drawing.Point(3, 7);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new System.Drawing.Size(234, 37);
            this.lblInstructions.Text = "Click Subscribe, and then press buttons on the handheld\'s keypad...";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 294);
            this.Controls.Add(this.lblInstructions);
            this.Controls.Add(this.listEvents);
            this.Controls.Add(this.btnUnsubscribe);
            this.Controls.Add(this.btnSubscribe);
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "KeyEventNotification";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSubscribe;
        private System.Windows.Forms.Button btnUnsubscribe;
        private System.Windows.Forms.ListBox listEvents;
        private System.Windows.Forms.Label lblInstructions;
    }
}


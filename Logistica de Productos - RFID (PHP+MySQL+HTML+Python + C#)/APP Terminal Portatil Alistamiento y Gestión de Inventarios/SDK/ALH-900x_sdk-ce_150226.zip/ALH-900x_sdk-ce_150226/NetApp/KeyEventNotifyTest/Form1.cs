﻿using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using NSysSvcApi;

namespace KeyEventNotifyTest
{
    public partial class Form1 : Form
    {
        SysSvcApi SysService = null;

        public const int WM_KEYUP = 0x0101;
        public const int WM_KEYDOWN = 0x0100;

        public Form1()
        {
            InitializeComponent();

            SysService = new SysSvcApi();
        }

        public void KeyEventCallbackProc(int KeyValue, int KeyState)
        {
            String msg = String.Empty;
            
            if (Environment.OSVersion.Version.Minor == 2)
            {
                // Windows Mobile
                msg = String.Format("Value:0x{0:X},  State:{1}", KeyValue, KeyState == WM_KEYUP ? "Up" : "Down");
            }
            else
            {
                // Windows CE
                Keys key = (Keys)KeyValue;
                msg = String.Format("Value:{0},  State:{1}", key.ToString(), KeyState == WM_KEYUP ? "Up" : "Down");
            }
            
            listEvents.Items.Add(msg);
            listEvents.SelectedIndex = listEvents.Items.Count - 1;
        }

        private void buttonSubscribe_Click(object sender, EventArgs e)
        {
            SYSSVC_RESULT result = SysService.KeyEventNotificationSet(new SysSvcApi.KeyEventNotifyCALLBACK(KeyEventCallbackProc));
            listEvents.Items.Add(result.ToString());
            listEvents.SelectedIndex = listEvents.Items.Count - 1;
        }

        private void buttonUnsubscribe_Click(object sender, EventArgs e)
        {
            SYSSVC_RESULT result = SysService.KeyEventNotificationReset();
            listEvents.Items.Add(result.ToString());
            listEvents.SelectedIndex = listEvents.Items.Count - 1;
        }
    }
}
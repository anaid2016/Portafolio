﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using NBarcodeApi;

namespace Barcode_Demo
{
    public partial class Barcode : Form
    {
        // NBarcodeApi Dll Class Object. 
        BarcodeApi barcode;

        #region  ########## Play_Sound ##########
        [DllImport("coredll.dll")]
        private static extern int PlaySound(string szSound, IntPtr hModule, int flags);

        private enum PlaySoundFlags : int
        {
            SND_SYNC = 0x0,     // play synchronously (default)
            SND_ASYNC = 0x1,    // play asynchronously
            SND_NODEFAULT = 0x2,    // silence (!default) if sound not found
            SND_MEMORY = 0x4,       // pszSound points to a memory file
            SND_LOOP = 0x8,     // loop the sound until next sndPlaySound
            SND_NOSTOP = 0x10,      // don't stop any currently playing sound
            SND_NOWAIT = 0x2000,    // don't wait if the driver is busy
            SND_ALIAS = 0x10000,    // name is a registry alias
            SND_ALIAS_ID = 0x110000,// alias is a predefined ID
            SND_FILENAME = 0x20000, // name is file name
            SND_RESOURCE = 0x40004, // name is resource name or atom
        };
        public void Play_Sound(string fileName)
        {
            PlaySound(fileName, IntPtr.Zero, (int)(PlaySoundFlags.SND_FILENAME | PlaySoundFlags.SND_ASYNC));
        }
        public void Play_Sound_NOSTOP(string fileName)
        {
            PlaySound(fileName, IntPtr.Zero, (int)(PlaySoundFlags.SND_FILENAME | PlaySoundFlags.SND_ASYNC | PlaySoundFlags.SND_NOSTOP));
        }
        #endregion

        public Barcode()
        {

            BARCODE_RESULT res;
            InitializeComponent();

             this.KeyPreview = true;
            // Declaration.
             barcode = new BarcodeApi();

            //===============================================================
             // Power on the Barcode and the Barcode device to the
            // device to initialize. Required system resource is allocated
            res = barcode.Open();

            // if successful, will return to BARCODE_RESULT_SUCCESS.
            if (res != BARCODE_RESULT.BARCODE_RESULT_SUCCESS)
            {
                if (res == BARCODE_RESULT.BARCODE_RESULT_CAM_SELECTED)
                    MessageBox.Show("CAM already turned on!!\r\nTry again after turn off CAM");
                else if (res == BARCODE_RESULT.BARCODE_RESULT_ALREADY_BARCODE_SELECTED)
                    MessageBox.Show("Already exists barcode application!!");
                else
                    MessageBox.Show(res.ToString());

                btnScan.Enabled = false;
                btnClear.Enabled = false;

                Application.Exit();
            }

            //===============================================================
            // When barcode scaning is complete, the Barcode system driver is called
            // by an application to register a callback function.
            barcode.SetCallback(new BarcodeApi.BARCODECALLBACK(BarcodeAppCallBack));
        }

        void BarcodeAppCallBack()
        {
            this.btnScan.Text = "Scan";

            string Value = new string(new char[512]);
            string SymName = new string(new char[512]);
            string SymType = new string(new char[2]);

            // Recognition succeded reads the barcode information.
            barcode.GetBarcodeData(ref Value, ref SymName, ref SymType);

            // View a list of bar code information is output as a control.
            ListViewItem item = new ListViewItem(Value);
            item.SubItems.Add(SymName);
            //item.SubItems.Add(SymType);

            lsvScanned.Items.Add(item);
            lsvScanned.Items[lsvScanned.Items.Count - 1].Selected = true;

            lsvScanned.EnsureVisible(lsvScanned.Items.Count - 1);

            Play_Sound_NOSTOP(@"\Windows\Success.wav");
        }

        private void btnScan_Click(object sender, EventArgs e)
        {
            BARCODE_RESULT res;

            if (this.btnScan.Text == "Scan")
            {
                // Barcode scanning is started
                res = barcode.Start();

                //=============================================================
                // if barcode Barcode scanning is successfully started to return to
                // BARCODE_RESULT_SUCCESS.
                if (res == BARCODE_RESULT.BARCODE_RESULT_SUCCESS)
                    this.btnScan.Text = "Stop";
                else
                    MessageBox.Show(res.ToString());
            }
            else
            {
                // Barcode scanning is stoppend.
                res = barcode.Stop();

                //=============================================================
                // Barcode scanning operation should return to normal
                // BARCODE_RESULT_SUCCESS is interrupted.

                if (res == BARCODE_RESULT.BARCODE_RESULT_SUCCESS)
                    this.btnScan.Text = "Scan";
                else
                    MessageBox.Show(res.ToString());
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Clear the list view control is a barcode information.
            lsvScanned.Items.Clear();
        }

        // trigger to start Barcode scanning barcodes.
        //private void Barcode_Demo_KeyDown(object sender, KeyEventArgs e)
        protected override void OnKeyDown(KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F1:
                case Keys.F2:
                case Keys.F7:
                case Keys.F8:
                case Keys.F9:

                    if (0 == this.btnScan.Text.CompareTo("Stop"))
                        return;

                    barcode.Start();
                    this.btnScan.Enabled = false;
                    break;

                default:
                    break;
            }
            base.OnKeyDown(e);
        }

        // Ttaeteulttae barcode scanning is a key trigger to stop.
        protected override void OnKeyUp(KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F1:
                case Keys.F2:
                case Keys.F7:
                case Keys.F8:
                case Keys.F9:
                    if (0 == this.btnScan.Text.CompareTo("Stop"))
                        return;

                    barcode.Stop();
                    this.btnScan.Enabled = true;
                    break;
                default:
                    break;
            }

            base.OnKeyUp(e);
        }

        protected override void OnClosed(EventArgs e)
        {

            //=============================================================
            // Remove the power of the Barcode device and disable the resource is assigned.
            barcode.Close();

            this.Dispose();
            base.OnClosed(e);
        }

        private void Barcode_Load(object sender, EventArgs e)
        {

        }

    }
}
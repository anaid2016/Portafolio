﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using NRfidApi;

namespace SelectTest
{
    public partial class Form2 : Form
    {
        public NRfidApi.RFIDSELMASKPARAMS_EX param;
        char[] HexValues = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

        public Form2()
        {
            InitializeComponent();
            this.Text = "SELECT Parameters";

            param = new NRfidApi.RFIDSELMASKPARAMS_EX();

            comboBox1.SelectedIndex = 4;
            comboBox2.SelectedIndex = 0;
            comboBox3.SelectedIndex = 1;
            textBox1.Text = "0";
            textBox2.Text = "8";
            textBox3.Text = "00";

            int x = (240 / 2) - (this.Width / 2);
            int y = (295 / 2) - (this.Height / 2);
            this.Location = new Point(x, y);
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox3.Text.Trim().Length % 2 != 0)
            {
                textBox3.Focus();
                textBox3.SelectAll();
                return;
            }

            foreach (char ch in textBox3.Text.Trim())
            {
                if (Array.IndexOf(HexValues, Char.ToUpper(ch), 0, HexValues.Length) < 0)
                {
                    MessageBox.Show("FormatException");
                    textBox3.Focus();
                    textBox3.SelectAll();
                    return;
                }
            }

            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    param.SelectTarget = SELECT_TARGET.S0;
                    break;
                case 1:
                    param.SelectTarget = SELECT_TARGET.S1;
                    break;
                case 2:
                    param.SelectTarget = SELECT_TARGET.S2;
                    break;
                case 3:
                    param.SelectTarget = SELECT_TARGET.S3;
                    break;
                case 4:
                    param.SelectTarget = SELECT_TARGET.SL;
                    break;
            }

            switch (comboBox2.SelectedIndex)
            {
                case 0:
                    param.ActionCode = SELECT_ACTION.ACTION_0;
                    break;
                case 1:
                    param.ActionCode = SELECT_ACTION.ACTION_1;
                    break;
                case 2:
                    param.ActionCode = SELECT_ACTION.ACTION_2;
                    break;
                case 3:
                    param.ActionCode = SELECT_ACTION.ACTION_3;
                    break;
                case 4:
                    param.ActionCode = SELECT_ACTION.ACTION_4;
                    break;
                case 5:
                    param.ActionCode = SELECT_ACTION.ACTION_5;
                    break;
                case 6:
                    param.ActionCode = SELECT_ACTION.ACTION_6;
                    break;
                case 7:
                    param.ActionCode = SELECT_ACTION.ACTION_7;
                    break;
            }

            switch (comboBox3.SelectedIndex)
            {
                case 0:
                    param.MemBank = MEM_BANK.RESERVED;
                    break;
                case 1:
                    param.MemBank = MEM_BANK.EPC;
                    break;
                case 2:
                    param.MemBank = MEM_BANK.TID;
                    break;
                case 3:
                    param.MemBank = MEM_BANK.USER;
                    break;
            }

            try
            {
                param.OffSet = Convert.ToUInt32(textBox1.Text.Trim());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                textBox1.Focus();
                textBox1.SelectAll();
                return;
            }

            try
            {
                param.Bits = Convert.ToUInt32(textBox2.Text.Trim());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                textBox2.Focus();
                textBox2.SelectAll();
                return;
            }

            string strPattern = textBox3.Text.Trim();
            param.MaskPattern = new byte[RfidApi.MAX_MASK_BYTES];
            for (int n = 0; n < strPattern.Length / 2; n++)
            {
                param.MaskPattern[n] = Convert.ToByte(strPattern.Substring(n * 2, 2), 16);
            }

            this.DialogResult = DialogResult.OK;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using NCamApi;

namespace Camera_Demo
{
    public partial class Camera : Form
    {
        #region  ########## Play_Sound ##########
        [DllImport("coredll.dll")]
        private static extern int PlaySound(string szSound, IntPtr hModule, int flags);

        private enum PlaySoundFlags : int
        {
            SND_SYNC = 0x0,     // play synchronously (default)
            SND_ASYNC = 0x1,    // play asynchronously
            SND_NODEFAULT = 0x2,    // silence (!default) if sound not found
            SND_MEMORY = 0x4,       // pszSound points to a memory file
            SND_LOOP = 0x8,     // loop the sound until next sndPlaySound
            SND_NOSTOP = 0x10,      // don't stop any currently playing sound
            SND_NOWAIT = 0x2000,    // don't wait if the driver is busy
            SND_ALIAS = 0x10000,    // name is a registry alias
            SND_ALIAS_ID = 0x110000,// alias is a predefined ID
            SND_FILENAME = 0x20000, // name is file name
            SND_RESOURCE = 0x40004, // name is resource name or atom
        };
        public void Play_Sound(string fileName)
        {
            PlaySound(fileName, IntPtr.Zero, (int)(PlaySoundFlags.SND_FILENAME | PlaySoundFlags.SND_ASYNC));
        }
        public void Play_Sound_NOSTOP(string fileName)
        {
            PlaySound(fileName, IntPtr.Zero, (int)(PlaySoundFlags.SND_FILENAME | PlaySoundFlags.SND_ASYNC | PlaySoundFlags.SND_NOSTOP));
        }
        #endregion
        // NCamApi Dll Class Object. 
        CamApi cam = null;
        SENSOR_SETUP_INFO sensor;
        SENSOR_CAPA SensorCapa;

        public Camera()
        {
            InitializeComponent();

            cmbFlash.SelectedIndex = 0;

            //==============================================
            // 1. Declaration. 
            // 2. Preview image preview image of the application windows handle
            // (picCamImage.Handle) are registered.
            cam = new CamApi(picCamImage.Handle);

            cam.SetCallBack(new CamApi.CAMERACALLBACK(CamCallBack));

            // Required to open the camera device is assigned system resources.
            CAM_RESULT result = cam.Open();
            if (result != CAM_RESULT.CAM_RESULT_SUCCESS)
            {
                if (result == CAM_RESULT.CAM_RESULT_SCAN_SELECTED)
                    MessageBox.Show("2D Barcode Scanner already turned on!!\r\nTry again after turn off 2D Barcode Scanner");
                else if (result == CAM_RESULT.CAM_RESULT_ALREADY_CAM_SELECTED)
                    MessageBox.Show("Already exists CAM application!!");
                else
                    MessageBox.Show(result.ToString());

                Application.Exit();
            }
   
            // Setting structure sensor
            sensor = new SENSOR_SETUP_INFO();

            // Calculate the value of the current settings of the camera module.
            cam.GetInfo(ref sensor);


            #region Setting Image mode
            //////////////////////////////////////////////////
            // Setting Image Mode.
            cmbImgMode.Items.Add("QQVGA");
            cmbImgMode.Items.Add("QVGA");
            cmbImgMode.Items.Add("CIF");
            cmbImgMode.Items.Add("VGA");
            cmbImgMode.Items.Add("SVGA");

            cmbImgMode.Items.Add("XGA");
            cmbImgMode.Items.Add("SSXGA");
            cmbImgMode.Items.Add("UXGA");
            cmbImgMode.Items.Add("QXGA");

            cmbImgMode.SelectedIndex = 3;
            cmbEffect.SelectedIndex = 0;

            #endregion

            // Getting Sensor Capa.
            SensorCapa = new SENSOR_CAPA();

            //======================================================
            // 1. The capability to support the camera module is calculated
            // 2. To change the values of the camera settings, you first use this function to find out
            //    the values that are supported by the module, and based on those values should be set.
            cam.GetSensorCapa(ref SensorCapa);

        }

         void CamCallBack(CamApi.CAMERAMSG camMsg)
         {
             switch (camMsg)
             {
                 case CamApi.CAMERAMSG.CAPTURE:
                     break;
                 case CamApi.CAMERAMSG.COMPLETE:
                     System.Diagnostics.Debug.WriteLine("File Save Completed");
                     Play_Sound(@"\Windows\Success.wav");
                     Cursor.Current = Cursors.Default;
                     cam.StartPreview();
                     break;
                 default:
                     break;
             }
         }
  
        private void btnOpen_Click(object sender, EventArgs e)
        {
            CAM_RESULT result = cam.StartPreview();
            if (result != CAM_RESULT.CAM_RESULT_SUCCESS)
            {
                MessageBox.Show(result.ToString());
            }
            /*
            if (this.btnOpen.Text.CompareTo("Open") == 0)
            {
                //the image data input from camera module to be drawing.
                cam.StartPreview();
                this.btnOpen.Text = "Pause";
            }
            else if (this.btnOpen.Text.CompareTo("Pause") == 0)
            {
                // Preview is suspended.
                cam.PausePreview();
                this.btnOpen.Text = "Resume";
            }
            else
            {
                // Preview is Resume
                cam.ResumePreview();
                this.btnOpen.Text = "Pause";
            }
            */
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            CAM_RESULT result = cam.StopPreview();
            if (result != CAM_RESULT.CAM_RESULT_SUCCESS)
            {
                MessageBox.Show(result.ToString());
            }
            else
            {
                picCamImage.Refresh();
            }
            //Preview will stop.
            //cam.StopPreview();

            //this.btnOpen.Text = "Open";
        }

        private void Camera_Closed(object sender, EventArgs e)
        {   
            // Release system resources allocated to the device close to the camera.
            
        }

        private void btnCapture_Click(object sender, EventArgs e)
        {
            // Structure of the required information at the tie of image capture.
            CAPTURE_SETUP_INFO capParam = new CAPTURE_SETUP_INFO();                    

            capParam.SensorSetup = sensor;
            capParam.sSavePath = "\\Flash Disk\\" + DateTime.Now.Year.ToString() +
                                                    DateTime.Now.Month.ToString() +
                                                    DateTime.Now.Day.ToString().PadLeft(2, '0') +
                                                    DateTime.Now.Hour.ToString().PadLeft(2, '0') +
                                                    DateTime.Now.Minute.ToString().PadLeft(2, '0') +
                                                    DateTime.Now.Second.ToString().PadLeft(2, '0') + ".jpg";
            
            //================================================================
            //capParam.sSavePath = "\\12345678901234567890.jpg";
            //capParam.nTemp = 10;
            capParam.imgFormat = IMG_ENCODE_FORMAT.IMG_ENCODE_JPG;
            capParam.nJpegQuality = 100;
            capParam.SensorSetup.ColorSpace = CAM_COL_SP.YCbCr;
            capParam.SensorSetup.bpp = CAM_BPP.YCbCr422;
            capParam.SensorSetup.FlipMirror = FLIP_MIRROR.MIRR;
            capParam.SensorSetup.WhiteBalance = WHITE_BAL.WB_AUTO;


            Cursor.Current = Cursors.WaitCursor;
            //=================================================================
            // CAPTURE_SETUP_INFO Parameter passed to change the settings on the camera module and
            // camera module input from peach to save the image data to a file.
            CAM_RESULT res = cam.Capture(ref capParam);
            if (res == CAM_RESULT.CAM_RESULT_SUCCESS)
            {
                Play_Sound(@"\Windows\Success.wav");
            }
            else
            {
                Play_Sound(@"\Windows\Fail.wav");
                MessageBox.Show(res.ToString());
            }
            

            //if (res == RESULT.RESULT_OK)
            //    this.btnOpen.Text = "Open";
            //else
            //    MessageBox.Show(res.ToString());
        }

        private void btnEffect_Click(object sender, EventArgs e)
        {
            switch(cmbEffect.SelectedIndex)
            {
                case 0: // White Balance
                    if (sensor.WhiteBalance == WHITE_BAL.WB_AUTO)
                        sensor.WhiteBalance = WHITE_BAL.WB_CLOUDY;
                    else if (sensor.WhiteBalance == WHITE_BAL.WB_CLOUDY)
                        sensor.WhiteBalance = WHITE_BAL.WB_FLUORESCENT;
                    else if (sensor.WhiteBalance == WHITE_BAL.WB_FLUORESCENT)
                        sensor.WhiteBalance = WHITE_BAL.WB_INCANDESCENT;
                    else if (sensor.WhiteBalance == WHITE_BAL.WB_INCANDESCENT)
                        sensor.WhiteBalance = WHITE_BAL.WB_SUNNY;
                    else if (sensor.WhiteBalance == WHITE_BAL.WB_SUNNY)
                        sensor.WhiteBalance = WHITE_BAL.WB_UNSUPPORTED;
                    else
                        sensor.WhiteBalance = WHITE_BAL.WB_AUTO;

                    cam.SetWhiteBalance(ref sensor);
                    break;
                case 1: // Contrast
                    if (sensor.Contrast == (CONT_OPTIONS)5)
                        sensor.Contrast = (CONT_OPTIONS)(-5);
                    else
                        sensor.Contrast++;

                    cam.SetContrast(ref sensor);
                    break;
                case 2: // Saturation
                    if (sensor.Saturation == (SAT_OPTIONS)4)
                        sensor.Saturation = (SAT_OPTIONS)(-4);
                    else
                        sensor.Saturation++;

                    cam.SetSaturation(ref sensor);
                    break;
                case 3: // Brightness
                    if(sensor.Brightness == SensorCapa.Brightness.BrightMax)
                        sensor.Brightness = SensorCapa.Brightness.BrightMin;
                    else
                        sensor.Brightness++;

                    cam.SetBrightness(ref sensor);
                    break;
                case 4: // Effect
                    if (sensor.Effect == EFFECT.EF_VIOLET)
                        sensor.Effect = EFFECT.NO_EFFECT;
                    else
                        sensor.Effect++;

                    cam.SetEffect(ref sensor);
                    break;
                case 5: // Flip
                    if (sensor.FlipMirror == FLIP_MIRROR.NO_MIRROR_FLIP)
                        sensor.FlipMirror = FLIP_MIRROR.MIRR;
                    else if (sensor.FlipMirror == FLIP_MIRROR.MIRR)
                        sensor.FlipMirror = FLIP_MIRROR.FLIP;
                    else if (sensor.FlipMirror == FLIP_MIRROR.FLIP)
                        sensor.FlipMirror = FLIP_MIRROR.FLIP_AND_MIRROR;
                    else if (sensor.FlipMirror == FLIP_MIRROR.FLIP_AND_MIRROR)
                        sensor.FlipMirror = FLIP_MIRROR.MIRR_FLIP_UNSUPPORTED;
                    else
                        sensor.FlipMirror = FLIP_MIRROR.NO_MIRROR_FLIP;

                    cam.SetFlipMirror(ref sensor);
                    break;
                case 6: // Auto Focus
                    sensor.bAutoFocus = true;
                    cam.SetAutoFocus(ref sensor);
                    break;
                default:
                    break;
            }
        }

        private void cmbFlash_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cam != null)
            {
                if (cmbFlash.SelectedIndex == 0)
                    cam.EnableFlash(false);
                else
                    cam.EnableFlash(true);
            }
        }

        private void Camera_Closing(object sender, CancelEventArgs e)
        {
            if (cmbFlash.SelectedIndex == 1)
                cam.EnableFlash(false);

            if(cam.IsOpen())
                cam.Close();
        }
    }
}
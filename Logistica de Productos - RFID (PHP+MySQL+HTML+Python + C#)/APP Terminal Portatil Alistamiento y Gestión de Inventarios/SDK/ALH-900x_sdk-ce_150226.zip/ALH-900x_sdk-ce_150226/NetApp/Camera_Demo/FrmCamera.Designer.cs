﻿namespace Camera_Demo
{
    partial class Camera
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form

        private void InitializeComponent()
        {
            this.picCamImage = new System.Windows.Forms.PictureBox();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnCapture = new System.Windows.Forms.Button();
            this.cmbImgMode = new System.Windows.Forms.ComboBox();
            this.btnSetEffect = new System.Windows.Forms.Button();
            this.cmbEffect = new System.Windows.Forms.ComboBox();
            this.cmbFlash = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // picCamImage
            // 
            this.picCamImage.Location = new System.Drawing.Point(3, 0);
            this.picCamImage.Name = "picCamImage";
            this.picCamImage.Size = new System.Drawing.Size(230, 194);
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(3, 197);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(70, 20);
            this.btnOpen.TabIndex = 1;
            this.btnOpen.Text = "Start";
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(79, 197);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 20);
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "Stop";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnCapture
            // 
            this.btnCapture.Location = new System.Drawing.Point(3, 246);
            this.btnCapture.Name = "btnCapture";
            this.btnCapture.Size = new System.Drawing.Size(110, 20);
            this.btnCapture.TabIndex = 1;
            this.btnCapture.Text = "Capture";
            this.btnCapture.Click += new System.EventHandler(this.btnCapture_Click);
            // 
            // cmbImgMode
            // 
            this.cmbImgMode.Location = new System.Drawing.Point(3, 220);
            this.cmbImgMode.Name = "cmbImgMode";
            this.cmbImgMode.Size = new System.Drawing.Size(110, 23);
            this.cmbImgMode.TabIndex = 3;
            // 
            // btnSetEffect
            // 
            this.btnSetEffect.Location = new System.Drawing.Point(123, 246);
            this.btnSetEffect.Name = "btnSetEffect";
            this.btnSetEffect.Size = new System.Drawing.Size(110, 20);
            this.btnSetEffect.TabIndex = 5;
            this.btnSetEffect.Text = "Set Effect";
            this.btnSetEffect.Click += new System.EventHandler(this.btnEffect_Click);
            // 
            // cmbEffect
            // 
            this.cmbEffect.Items.Add("White Balance");
            this.cmbEffect.Items.Add("Contrast");
            this.cmbEffect.Items.Add("Saturation");
            this.cmbEffect.Items.Add("Brightness");
            this.cmbEffect.Items.Add("Effect");
            this.cmbEffect.Items.Add("Flip");
            this.cmbEffect.Items.Add("AutoFocus");
            this.cmbEffect.Location = new System.Drawing.Point(123, 220);
            this.cmbEffect.Name = "cmbEffect";
            this.cmbEffect.Size = new System.Drawing.Size(110, 23);
            this.cmbEffect.TabIndex = 7;
            // 
            // cmbFlash
            // 
            this.cmbFlash.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.cmbFlash.Items.Add("Flash Off");
            this.cmbFlash.Items.Add("Flash On");
            this.cmbFlash.Location = new System.Drawing.Point(160, 197);
            this.cmbFlash.Name = "cmbFlash";
            this.cmbFlash.Size = new System.Drawing.Size(73, 19);
            this.cmbFlash.TabIndex = 9;
            this.cmbFlash.SelectedIndexChanged += new System.EventHandler(this.cmbFlash_SelectedIndexChanged);
            // 
            // Camera
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(638, 455);
            this.Controls.Add(this.cmbFlash);
            this.Controls.Add(this.cmbEffect);
            this.Controls.Add(this.btnSetEffect);
            this.Controls.Add(this.cmbImgMode);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCapture);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.picCamImage);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Camera";
            this.Text = "Camera";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Closed += new System.EventHandler(this.Camera_Closed);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.Camera_Closing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picCamImage;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnCapture;
        private System.Windows.Forms.ComboBox cmbImgMode;
        private System.Windows.Forms.Button btnSetEffect;
        private System.Windows.Forms.ComboBox cmbEffect;
        private System.Windows.Forms.ComboBox cmbFlash;
    }
}


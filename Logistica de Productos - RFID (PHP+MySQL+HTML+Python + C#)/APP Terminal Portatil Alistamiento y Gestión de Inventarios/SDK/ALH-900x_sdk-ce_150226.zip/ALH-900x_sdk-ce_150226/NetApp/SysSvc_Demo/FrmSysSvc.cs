﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using NSysSvcApi;

namespace SysSvc_Demo
{
    public partial class FrmSysSvc : Form
    {
        private struct BackLightBrightness
        {
            public ushort WriteValueInAC;
            public bool   isChangeInAC;
            public ushort WriteValueinBAT;
            public bool   isChangeInBAT;
        }

        SysSvcApi SysService;
        BackLightBrightness Brightness;

        // Backlight
        public void InitBacklightPage()
        {
            // usValue = Mode passed to the time-out value is set power save mode.
            ushort usValue = new ushort();
            // Backlight brightness set to the power mode, calculate.
            SysService.BacklightReadBrightness(SysSvcApi.MODE_AC, ref usValue);
            comboBox7.SelectedIndex = 0;
            numericUpDown5.Value = usValue;
            Brightness.WriteValueInAC = usValue;
            SysService.BacklightReadBrightness(SysSvcApi.MODE_BAT, ref usValue);
            Brightness.WriteValueinBAT = usValue;
            // For each power mode, set the current time-out value is calculated.
            SysService.BacklightReadTimeoutValue(SysSvcApi.MODE_AC, ref usValue);
            comboBox8.SelectedIndex = 0;
            numericUpDown6.Value = usValue;
        }

        // KeyLamp
        public void InitKeyLampPage()
        {
            bool bEnable = false;
            // Save time set
            ushort usValue = 0;
            ushort usHourFrom, usMinuteFrom, usHourTo, usMinuteTo;

            usHourFrom = usMinuteFrom = usHourTo = usMinuteTo = 0;

            // key, then key off until the lamp comes loaded with a set time.
            SysService.KeyLampReadTimeoutValue(ref usValue);
            numericUpDown4.Value = usValue;

            // key features set off the current value of the lamp reads.
            SysService.KeyLampReadOffTimeEnable(ref bEnable);
            comboBox6.SelectedIndex = bEnable ? 0 : 1;

            // do not use the zone's key lamp start time, end time, the value is read.
            SysService.KeyLampReadOffTimeValue(ref usHourFrom, ref usMinuteFrom, ref usHourTo, ref usMinuteTo);

            numericUpDown7.Value = usHourFrom;      // Start Hour
            numericUpDown8.Value = usMinuteFrom;    // start minutes
            numericUpDown9.Value = usHourTo;        // End Hour
            numericUpDown10.Value = usMinuteTo;     // End minutes
        }

        public void InitOthersPage()
        {
            bool bEnabled = false;
            IPM_PRODUCT_OP Op = new IPM_PRODUCT_OP();
            ushort usValue = new ushort();
            //AUDIOCODECVOLCTL audioCodec = new AUDIOCODECVOLCTL();

            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;

            textBox1.Text = SysService.DeviceID;
            textBox2.Text = SysService.UUID;

            // External power mode is set to battery mode suspend time-out value is read.
            SysService.SuspendReadTimeoutValue(SysSvcApi.MODE_AC, ref usValue);
            comboBox1.SelectedIndex = 0;
            numericUpDown1.Value = usValue;

            // Calculate the current power state of the WLAN module.
            SysService.GetWlanPowerStatus(ref bEnabled);
            comboBox2.SelectedIndex = bEnabled ? 0 : 1;
            comboBox3.SelectedIndex = 1;

            // Mic, speaker reads the value of the volume.
            SysService.ReadAudioCodecGainLevel(AUDIOCODECVOLUME.CODEC_SPEAKER_VOLUME, ref usValue);
            numericUpDown2.Value = usValue;
            
            SysService.ReadAudioCodecGainLevel(AUDIOCODECVOLUME.CODEC_MIC_VOLUME, ref usValue);
            numericUpDown3.Value = usValue;


            // Seek to set the current CPU clock mode.
            SysService.GetCpuClock(ref Op);
            switch (Op)
            {
                case IPM_PRODUCT_OP.IPM_OP_208MHZ:
                    comboBox4.SelectedIndex = 0;
                    break;
                case IPM_PRODUCT_OP.IPM_OP_416MHZ:
                    comboBox4.SelectedIndex = 1;
                    break;
                case IPM_PRODUCT_OP.IPM_OP_624MHZ:
                    comboBox4.SelectedIndex = 2;
                    break;
                case IPM_PRODUCT_OP.IPM_OP_806MHZ:
                    comboBox4.SelectedIndex = 3;
                    break;
                case IPM_PRODUCT_OP.IPM_OP_AUTO:
                    comboBox4.SelectedIndex = 4;
                    break;
            }

            comboBox5.SelectedIndex = 1;
        }

        public FrmSysSvc()
        {
            InitializeComponent();

            //m_usValue = new ushort();
            Brightness = new BackLightBrightness();
            Brightness.isChangeInAC = false;
            Brightness.isChangeInBAT = false;

            SysService = new SysSvcApi();
            InitBacklightPage();
        }

        private void FrmSysSvc_Load(object sender, EventArgs e)
        {

        }

        private void pnlBacklight_GotFocus(object sender, EventArgs e)
        {

        }

        public void SleepWakeupCallback(bool bEnterSleep)
        {
            if (bEnterSleep)
                MessageBox.Show("SleepWakeupCallback : Sleep");
            else
                MessageBox.Show("SleepWakeupCallback : Wakeup");
        }


        private void button5_Click(object sender, EventArgs e)
        {
            // Sleep/wakeup notification service and receive an application to register a callback.
            SysService.SleepWakeupNotificationSet(new SysSvcApi.SleepWakeupNotifyCALLBACK(SleepWakeupCallback));
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // Registered sleep /wakeup notification service frees a callback.
            SysService.SleepWakeupNotificationReset();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (tabControl1.SelectedIndex)
            {
                case 0:
                    InitBacklightPage();
                    break;
                case 1:
                    InitKeyLampPage();
                    break;
                case 2:
                    InitOthersPage();
                    break;
                default:
                    break;
            }
        }

        // Vibrator motor and enable / disable the.
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3.SelectedIndex == 0)
                SysService.SetVibratorEnable(true);
            else
                SysService.SetVibratorEnable(false);
        }

        // WLAN module or the power is removed.
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool pwr = false;

            Cursor.Current = Cursors.WaitCursor;
            SysService.GetWlanPowerStatus(ref pwr);
            if (comboBox2.SelectedIndex == 0)
            {
                if(!pwr)
                    SysService.SetWlanPowerEnable(true);
            }
            else
            {
                if(pwr)
                    SysService.SetWlanPowerEnable(false);
            }
            Cursor.Current = Cursors.Default;
        }


        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            ushort usValue = new ushort();
            Byte Mode = new byte();
            if (comboBox7.SelectedIndex == 0)
                Mode = SysSvcApi.MODE_AC;
            else
                Mode = SysSvcApi.MODE_BAT;

            // Backlight brightness set to the power mode, calculate.
            SysService.BacklightReadBrightness(Mode, ref usValue);
            numericUpDown5.Value = usValue;
        }

        private void numericUpDown5_ValueChanged(object sender, EventArgs e)
        {
            // In the current power mode set the backlight brightness values.
            SysService.BacklightSetBrightness((ushort)numericUpDown5.Value);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Byte Mode = new byte();

            if (comboBox7.SelectedIndex == 0)
            {
                Mode = SysSvcApi.MODE_AC;
                Brightness.isChangeInAC = true;
                Brightness.WriteValueInAC = (ushort)numericUpDown5.Value;
            }
            else
            {
                Mode = SysSvcApi.MODE_BAT;
                Brightness.isChangeInBAT = true;
                Brightness.WriteValueinBAT = (ushort)numericUpDown5.Value;
            }

            // Backlight brightness values corresponding to the power mode is set.
            SysService.BacklightWriteBrightness(Mode, (ushort)numericUpDown5.Value);
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            ushort usValue = new ushort();
            Byte Mode = new byte();
            if (comboBox8.SelectedIndex == 0)
                Mode = SysSvcApi.MODE_AC;
            else
                Mode = SysSvcApi.MODE_BAT;

            // For each power mode, set the current time-out value is calculated.
            SysService.BacklightReadTimeoutValue(Mode, ref usValue);
            numericUpDown6.Value = usValue;
        }

        private void numericUpDown6_ValueChanged(object sender, EventArgs e)
        {
            //SysService.BacklightSetBrightness((ushort)numericUpDown6.Value);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Byte Mode = new byte();

            if (comboBox8.SelectedIndex == 0)
                Mode = SysSvcApi.MODE_AC;
            else
                Mode = SysSvcApi.MODE_BAT;

            // Power Mode time-out setting. User input(touch tap or key press)if no hours set the backlight is off.
            SysService.BacklightWriteTimeoutValue(Mode, (ushort)numericUpDown6.Value);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            ushort FromHour, FromMinute, ToHour, ToMinute;

            FromHour = (ushort)numericUpDown7.Value;
            FromMinute = (ushort)numericUpDown8.Value;
            ToHour = (ushort)numericUpDown9.Value;
            ToMinute = (ushort)numericUpDown10.Value;

            // Key dose not use the lamp to set the time zone.
            if (SysService.KeyLampWriteOffTimeValue(FromHour, FromMinute, ToHour, ToMinute) != SYSSVC_RESULT.SYSSVC_RESULT_SUCCESS)
                MessageBox.Show("KeyLampWriteOffTimeValue Failed");
        }

        private void numericUpDown4_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
     
            // Off ramp on the time set function key to enable or disable.
            if (comboBox6.SelectedIndex == 0)
            {
                SysService.KeyLampWriteOffTimeEnable(true);
            }
            else
            {
                SysService.KeyLampWriteOffTimeEnable(false);
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            // Finally, a key to the off ramp and then the amount of time setting.
            SysService.KeyLampWriteTimeoutValue((ushort)numericUpDown4.Value);
        }

        private void button4_Click(object sender, EventArgs e)
        {

            IPM_PRODUCT_OP Clock = new IPM_PRODUCT_OP();

            // Seek to set the current CPU clock mode.
            SysService.GetCpuClock(ref Clock);
            comboBox4.SelectedIndex = (int)Clock;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // CPU clock setting.
            SYSSVC_RESULT result = SYSSVC_RESULT.SYSSVC_RESULT_FAILURE;
            IPM_PRODUCT_OP value = IPM_PRODUCT_OP.IPM_OP_AUTO;

            switch (comboBox4.SelectedIndex)
            {
                case 0:
                    value = IPM_PRODUCT_OP.IPM_OP_208MHZ;
                    break;
                case 1:
                    value = IPM_PRODUCT_OP.IPM_OP_416MHZ;
                    break;
                case 2:
                    value = IPM_PRODUCT_OP.IPM_OP_624MHZ;
                    break;
                case 3:
                    value = IPM_PRODUCT_OP.IPM_OP_806MHZ;
                    break;
                case 4:
                    value = IPM_PRODUCT_OP.IPM_OP_AUTO;
                    break;
            }

            result = SysService.SetCpuClock(value);
            if (result != SYSSVC_RESULT.SYSSVC_RESULT_SUCCESS)
                MessageBox.Show(result.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Byte Mode = new byte();
            ushort usTimeout = new ushort();
            SYSSVC_RESULT result = new SYSSVC_RESULT();


            if (comboBox1.SelectedIndex == 0)
                Mode = SysSvcApi.MODE_AC;
            else
                Mode = SysSvcApi.MODE_BAT;

            // Power mode is set to suspend time-out value is read.
            result = SysService.SuspendReadTimeoutValue(Mode, ref usTimeout);
            if (result != SYSSVC_RESULT.SYSSVC_RESULT_SUCCESS)
            {
                MessageBox.Show(result.ToString());
                return;
            }

            numericUpDown1.Value = usTimeout;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Byte Mode = new byte();
            SYSSVC_RESULT result = new SYSSVC_RESULT();

            if (comboBox1.SelectedIndex == 0)
                Mode = SysSvcApi.MODE_AC;
            else
                Mode = SysSvcApi.MODE_BAT;

            // Power mode to suspend time-out value.
            result = SysService.SuspendWriteTimeoutValue(Mode, (ushort)numericUpDown1.Value);
            if (result != SYSSVC_RESULT.SYSSVC_RESULT_SUCCESS)
            {
                MessageBox.Show(result.ToString());
                return;
            }
        }

        private void FrmSysSvc_Closing(object sender, CancelEventArgs e)
        {
            if (!Brightness.isChangeInAC)
                SysService.BacklightWriteBrightness(SysSvcApi.MODE_AC, Brightness.WriteValueInAC);

            if (!Brightness.isChangeInBAT)
                SysService.BacklightWriteBrightness(SysSvcApi.MODE_BAT, Brightness.WriteValueinBAT);
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            // speaker of the default gain value is set.
            if (SysService.SetAudioCodecGainLevel(AUDIOCODECVOLUME.CODEC_SPEAKER_VOLUME, (ushort)numericUpDown2.Value)
                != SYSSVC_RESULT.SYSSVC_RESULT_SUCCESS)
            {
                MessageBox.Show("SetAudioCodecGainLevel Failed");
            }
        }

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            // MIC of the default gain value is set.
            if (SysService.SetAudioCodecGainLevel(AUDIOCODECVOLUME.CODEC_MIC_VOLUME, (ushort)numericUpDown3.Value)
                != SYSSVC_RESULT.SYSSVC_RESULT_SUCCESS)
            {
                MessageBox.Show("SetAudioCodecGainLevel Failed");
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            // Mic, speaker of the default gain value is recorded.
            if (SysService.WriteAudioCodecGainLevel(AUDIOCODECVOLUME.CODEC_SPEAKER_VOLUME, (ushort)numericUpDown2.Value)
                != SYSSVC_RESULT.SYSSVC_RESULT_SUCCESS)
            {
                MessageBox.Show("WriteAudioCodecGainLevel Failed");
            }

            if (SysService.WriteAudioCodecGainLevel(AUDIOCODECVOLUME.CODEC_MIC_VOLUME, (ushort)numericUpDown3.Value)
                != SYSSVC_RESULT.SYSSVC_RESULT_SUCCESS)
            {
                MessageBox.Show("WriteAudioCodecGainLevel Failed");
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            SysService.SoftReset();
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox5.SelectedIndex == 0)
                SysService.EnableFlashLight(true);
            else
                SysService.EnableFlashLight(false);
        }

    }
}
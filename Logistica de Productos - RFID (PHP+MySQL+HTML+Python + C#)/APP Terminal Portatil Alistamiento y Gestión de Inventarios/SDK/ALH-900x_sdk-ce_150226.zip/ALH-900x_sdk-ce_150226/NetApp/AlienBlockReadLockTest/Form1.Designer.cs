﻿namespace AlienBlockReadLockTest
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form

        private void InitializeComponent()
        {
            this.listBoxStatus = new System.Windows.Forms.ListBox();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnReadLock = new System.Windows.Forms.Button();
            this.chkPwd = new System.Windows.Forms.CheckBox();
            this.btnReveal = new System.Windows.Forms.Button();
            this.btnPermalock = new System.Windows.Forms.Button();
            this.cbReadBank = new System.Windows.Forms.ComboBox();
            this.nudReadPointer = new System.Windows.Forms.NumericUpDown();
            this.nudReadCount = new System.Windows.Forms.NumericUpDown();
            this.txtReadData = new System.Windows.Forms.TextBox();
            this.btnRead = new System.Windows.Forms.Button();
            this.btnWrite = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cbBlock1 = new System.Windows.Forms.CheckBox();
            this.cbBlock2 = new System.Windows.Forms.CheckBox();
            this.cbBlock4 = new System.Windows.Forms.CheckBox();
            this.cbBlock3 = new System.Windows.Forms.CheckBox();
            this.cbBlock8 = new System.Windows.Forms.CheckBox();
            this.cbBlock7 = new System.Windows.Forms.CheckBox();
            this.cbBlock6 = new System.Windows.Forms.CheckBox();
            this.cbBlock5 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // listBoxStatus
            // 
            this.listBoxStatus.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.listBoxStatus.Location = new System.Drawing.Point(4, 9);
            this.listBoxStatus.Name = "listBoxStatus";
            this.listBoxStatus.Size = new System.Drawing.Size(229, 67);
            this.listBoxStatus.TabIndex = 0;
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(186, 247);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(47, 20);
            this.btnStop.TabIndex = 2;
            this.btnStop.Text = "Stop";
            this.btnStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // btnReadLock
            // 
            this.btnReadLock.Location = new System.Drawing.Point(4, 82);
            this.btnReadLock.Name = "btnReadLock";
            this.btnReadLock.Size = new System.Drawing.Size(229, 20);
            this.btnReadLock.TabIndex = 6;
            this.btnReadLock.Text = "Read-lock the 1st and 3rd blocks";
            this.btnReadLock.Click += new System.EventHandler(this.buttonReadLock_Click);
            // 
            // chkPwd
            // 
            this.chkPwd.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.chkPwd.Location = new System.Drawing.Point(164, 183);
            this.chkPwd.Name = "chkPwd";
            this.chkPwd.Size = new System.Drawing.Size(71, 20);
            this.chkPwd.TabIndex = 10;
            this.chkPwd.Text = "with pwd";
            // 
            // btnReveal
            // 
            this.btnReveal.Location = new System.Drawing.Point(4, 108);
            this.btnReveal.Name = "btnReveal";
            this.btnReveal.Size = new System.Drawing.Size(229, 20);
            this.btnReveal.TabIndex = 12;
            this.btnReveal.Text = "Reveal the hidden blocks";
            this.btnReveal.Click += new System.EventHandler(this.buttonReveal_Click);
            // 
            // btnPermalock
            // 
            this.btnPermalock.Location = new System.Drawing.Point(4, 134);
            this.btnPermalock.Name = "btnPermalock";
            this.btnPermalock.Size = new System.Drawing.Size(229, 20);
            this.btnPermalock.TabIndex = 13;
            this.btnPermalock.Text = "Permalock these blocks:";
            this.btnPermalock.Click += new System.EventHandler(this.buttonPermalock_Click);
            // 
            // cbReadBank
            // 
            this.cbReadBank.Location = new System.Drawing.Point(16, 211);
            this.cbReadBank.Name = "cbReadBank";
            this.cbReadBank.Size = new System.Drawing.Size(62, 23);
            this.cbReadBank.TabIndex = 14;
            // 
            // nudReadPointer
            // 
            this.nudReadPointer.Location = new System.Drawing.Point(79, 211);
            this.nudReadPointer.Name = "nudReadPointer";
            this.nudReadPointer.Size = new System.Drawing.Size(43, 24);
            this.nudReadPointer.TabIndex = 15;
            // 
            // nudReadCount
            // 
            this.nudReadCount.Location = new System.Drawing.Point(123, 211);
            this.nudReadCount.Name = "nudReadCount";
            this.nudReadCount.Size = new System.Drawing.Size(43, 24);
            this.nudReadCount.TabIndex = 16;
            this.nudReadCount.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // txtReadData
            // 
            this.txtReadData.Location = new System.Drawing.Point(3, 239);
            this.txtReadData.Name = "txtReadData";
            this.txtReadData.Size = new System.Drawing.Size(176, 23);
            this.txtReadData.TabIndex = 17;
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(185, 203);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(47, 20);
            this.btnRead.TabIndex = 18;
            this.btnRead.Text = "Read";
            this.btnRead.Click += new System.EventHandler(this.buttonRead_Click);
            // 
            // btnWrite
            // 
            this.btnWrite.Location = new System.Drawing.Point(186, 225);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(47, 20);
            this.btnWrite.TabIndex = 19;
            this.btnWrite.Text = "Write";
            this.btnWrite.Click += new System.EventHandler(this.buttonWrite_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(17, 195);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 16);
            this.label1.Text = "MemBank";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(84, 195);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 16);
            this.label2.Text = "Ptr";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(124, 193);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 16);
            this.label3.Text = "Cnt";
            // 
            // cbBlock1
            // 
            this.cbBlock1.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.cbBlock1.Location = new System.Drawing.Point(2, 162);
            this.cbBlock1.Name = "cbBlock1";
            this.cbBlock1.Size = new System.Drawing.Size(34, 20);
            this.cbBlock1.TabIndex = 20;
            this.cbBlock1.Text = "1";
            // 
            // cbBlock2
            // 
            this.cbBlock2.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.cbBlock2.Location = new System.Drawing.Point(30, 162);
            this.cbBlock2.Name = "cbBlock2";
            this.cbBlock2.Size = new System.Drawing.Size(34, 20);
            this.cbBlock2.TabIndex = 21;
            this.cbBlock2.Text = "2";
            // 
            // cbBlock4
            // 
            this.cbBlock4.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.cbBlock4.Location = new System.Drawing.Point(86, 162);
            this.cbBlock4.Name = "cbBlock4";
            this.cbBlock4.Size = new System.Drawing.Size(34, 20);
            this.cbBlock4.TabIndex = 23;
            this.cbBlock4.Text = "4";
            // 
            // cbBlock3
            // 
            this.cbBlock3.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.cbBlock3.Location = new System.Drawing.Point(58, 162);
            this.cbBlock3.Name = "cbBlock3";
            this.cbBlock3.Size = new System.Drawing.Size(34, 20);
            this.cbBlock3.TabIndex = 22;
            this.cbBlock3.Text = "3";
            // 
            // cbBlock8
            // 
            this.cbBlock8.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.cbBlock8.Location = new System.Drawing.Point(204, 162);
            this.cbBlock8.Name = "cbBlock8";
            this.cbBlock8.Size = new System.Drawing.Size(34, 20);
            this.cbBlock8.TabIndex = 27;
            this.cbBlock8.Text = "8";
            // 
            // cbBlock7
            // 
            this.cbBlock7.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.cbBlock7.Location = new System.Drawing.Point(174, 162);
            this.cbBlock7.Name = "cbBlock7";
            this.cbBlock7.Size = new System.Drawing.Size(34, 20);
            this.cbBlock7.TabIndex = 26;
            this.cbBlock7.Text = "7";
            // 
            // cbBlock6
            // 
            this.cbBlock6.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.cbBlock6.Location = new System.Drawing.Point(145, 162);
            this.cbBlock6.Name = "cbBlock6";
            this.cbBlock6.Size = new System.Drawing.Size(34, 20);
            this.cbBlock6.TabIndex = 25;
            this.cbBlock6.Text = "6";
            // 
            // cbBlock5
            // 
            this.cbBlock5.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Regular);
            this.cbBlock5.Location = new System.Drawing.Point(115, 162);
            this.cbBlock5.Name = "cbBlock5";
            this.cbBlock5.Size = new System.Drawing.Size(34, 20);
            this.cbBlock5.TabIndex = 24;
            this.cbBlock5.Text = "5";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(238, 270);
            this.Controls.Add(this.cbBlock8);
            this.Controls.Add(this.cbBlock7);
            this.Controls.Add(this.cbBlock6);
            this.Controls.Add(this.cbBlock5);
            this.Controls.Add(this.cbBlock4);
            this.Controls.Add(this.cbBlock3);
            this.Controls.Add(this.cbBlock2);
            this.Controls.Add(this.cbBlock1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnWrite);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.txtReadData);
            this.Controls.Add(this.nudReadCount);
            this.Controls.Add(this.nudReadPointer);
            this.Controls.Add(this.cbReadBank);
            this.Controls.Add(this.btnPermalock);
            this.Controls.Add(this.btnReveal);
            this.Controls.Add(this.chkPwd);
            this.Controls.Add(this.btnReadLock);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.listBoxStatus);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "AlienBlockReadLockTest";
            this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxStatus;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnReadLock;
        private System.Windows.Forms.CheckBox chkPwd;
        private System.Windows.Forms.Button btnReveal;
        private System.Windows.Forms.Button btnPermalock;
        private System.Windows.Forms.ComboBox cbReadBank;
        private System.Windows.Forms.NumericUpDown nudReadPointer;
        private System.Windows.Forms.NumericUpDown nudReadCount;
        private System.Windows.Forms.TextBox txtReadData;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox cbBlock1;
        private System.Windows.Forms.CheckBox cbBlock2;
        private System.Windows.Forms.CheckBox cbBlock4;
        private System.Windows.Forms.CheckBox cbBlock3;
        private System.Windows.Forms.CheckBox cbBlock8;
        private System.Windows.Forms.CheckBox cbBlock7;
        private System.Windows.Forms.CheckBox cbBlock6;
        private System.Windows.Forms.CheckBox cbBlock5;
    }
}


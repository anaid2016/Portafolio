﻿using System;

using System.Collections.Generic;
using System.Windows.Forms;

namespace AlienBlockReadLockTest
{
    static class Program
    {
        [MTAThread]
        static void Main()
        {
            Application.Run(new Form1());
        }
    }
}